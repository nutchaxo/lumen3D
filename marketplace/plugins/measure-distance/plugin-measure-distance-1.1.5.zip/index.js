/* Measure Distance — index.js
 *
 * Migrates _handleVolumeMeasurePoint, _createVolumeMeasurement,
 * _renderVolumeMeasurement, _handleVolumeMeasureListClick,
 * _clearVolumeMeasurement, _setVolumeMeasureStatus,
 * _showMeasureColorPopup, _closeMeasureColorPopup, _distance3d,
 * _fmtUm (inline), MEASURE_PALETTE, MEASUREMENT_COLORS from viewer.js.
 *
 * This module manages its own measurement state locally, syncing it
 * with MeasurementStore via ctx.measurements.
 */
PluginRegistry.implement('measure-distance', {
  _ctx: null,
  _draft: [],         // Up to 2 pending raw pick points
  _measurements: [],  // Committed measurements from MeasurementStore
  _listNode: null,
  _clearNode: null,
  _onList: null,
  _onClear: null,

  // ─── Colour constants ──────────────────────────────────────
  PALETTE: [
    ['#FFD700', '#00FFFF', '#FF1493', '#7FFF00', '#FF4500'],
    ['#9400D3', '#00FF7F', '#FF69B4', '#1E90FF', '#FFFFFF']
  ],
  COLORS: ['#00FFFF','#FFD700','#FF1493','#7FFF00','#FF4500','#9400D3','#00FF7F','#FF69B4'],

  // Plugin-scoped i18n: resolves plugins.measure-distance.<key> with the
  // automatic English fallback when the active locale is not shipped here.
  _t(key, params) { return this._ctx.i18n.t(key, params); },

  // Re-render dynamic status/list text when the language changes.
  onLanguageChange() { this._render(); },

  init(ctx) {
    this._ctx = ctx;
    // Load persisted measurements
    this._measurements = ctx.measurements.list('viewer');

    // Hook VolumeViewer pick events
    ctx.viewer.onMeasurePoint(pt => this._handlePoint(pt));

    // Bind list interaction (toggle, delete, rename, color)
    this._onList = e => this._handleListEvent(e);
    this._onClear = () => this._clear();
    this._listNode = document.getElementById('volume-measure-list');
    this._listNode?.addEventListener('click', this._onList);
    this._listNode?.addEventListener('change', this._onList);

    // Clear button: the 2D page names it btn-measure-clear, the volume viewer
    // btn-clear-volume-measure. On the viewer the page clears the store with its own
    // handler too; this one also drops the plugin's pending first pick.
    this._clearNode = document.getElementById('btn-measure-clear')
      || document.getElementById('btn-clear-volume-measure');
    this._clearNode?.addEventListener('click', this._onClear);

    this._render();
    return this;
  },

  // ── Workspace state ───────────────────────────────────────

  /**
   * Read from the STORE, not from this._measurements. The store is the single
   * source of truth — the viewer writes it directly when it restores a workspace
   * (MeasurementStore.setAll), without going through this module, so the local
   * array is only a render cache and can be a restore behind. Reporting that cache
   * as workspace state saved an empty list over measurements that were on screen.
   */
  getState() {
    const items = this._ctx ? this._ctx.measurements.list('viewer') : this._measurements;
    return { measurements: items };
  },

  setState(s) {
    if (!s?.measurements) return;
    // A first pick made on the previous dataset must not pair with a click on this one.
    this._draft = [];
    this._measurements = this._ctx.measurements.setAll('viewer', s.measurements);
    this._ctx.viewer.setMeasurements(this._measurements);
    this._render();
  },

  reset() { this._clear(); },

  // ── Private ───────────────────────────────────────────────

  _handlePoint(point) {
    const calibration = this._ctx.viewer.getPhysicalCalibration?.();
    if (calibration?.calibrationStatus === 'metadata-missing') {
      this._setStatus(this._ctx.ui.escapeHtml(this._t('calibMissing')));
      return;
    }
    if (!point?.physicalUm) {
      this._setStatus(this._ctx.ui.escapeHtml(this._t('noPoint')));
      return;
    }
    // Nothing visible under the cursor: the ray only met the volume's box, whose
    // entry depth is not a point of the specimen — measuring it would be fiction.
    if (point.onBoundingBox) {
      this._setStatus(this._ctx.ui.escapeHtml(this._t('noStructure')));
      return;
    }
    if (this._draft.length >= 2) this._draft = [];
    this._draft.push(point);
    if (this._draft.length === 2) this._commit();
    this._render();
  },

  _commit() {
    if (this._draft.length !== 2) return;
    const [aPoint, bPoint] = this._draft;
    // The page may have written the store behind this module (its own Clear, a restore).
    const count = this._ctx.measurements.list('viewer').length;
    const color = this.COLORS[count % this.COLORS.length];
    this._ctx.measurements.add('viewer', {
      scope: 'viewer',
      label: this._t('measureN', { n: count + 1 }),
      unit: 'um',
      distance: this._dist3d(aPoint.physicalUm, bPoint.physicalUm),
      points: this._draft.map(p => ({ normalized: p.normalized, physicalUm: p.physicalUm })),
      timepoint: this._ctx._state.currentTimepoint,
      color
    });
    // BUG-031: re-read the store rather than manually pushing into the local mirror,
    // so the mirror is always exactly the store (the store normalizes/ids the entry,
    // and a manual push could drift if add() ever transforms it).
    this._measurements = this._ctx.measurements.list('viewer');
    this._draft = [];
    this._ctx.viewer.setMeasurements(this._measurements);
  },

  _clear() {
    this._draft = [];
    this._closeColorPopup();
    this._measurements = this._ctx.measurements.clear('viewer');
    this._ctx.viewer.setMeasurements(this._measurements);
    this._render();
  },

  _render() {
    const list = document.getElementById('volume-measure-list');
    const esc  = s => this._ctx.ui.escapeHtml(s);

    if (list) {
      const colorLabel  = esc(this._t('changeColor'));
      const deleteLabel = esc(this._t('deleteMeasure'));
      const nameLabel   = esc(this._t('labelPlaceholder'));
      list.innerHTML = this._measurements.length
        ? this._measurements.map(item => {
          const visLabel = esc(this._t(item.visible === false ? 'showMeasure' : 'hideMeasure'));
          return `
          <div class="measurement-row" style="display:flex;align-items:center;gap:4px;padding:4px 0;">
            <button class="btn btn-ghost btn-sm measure-color-btn" type="button"
              data-volume-measure-action="toggle-color" data-measurement-id="${esc(item.id)}"
              title="${colorLabel}" aria-label="${colorLabel}" aria-haspopup="true"
              style="padding:0;width:24px;height:24px;border:none;flex-shrink:0;">
              <span aria-hidden="true" style="background:${this._safeColor(item.color)};width:16px;height:16px;display:inline-block;border-radius:3px;border:1px solid rgba(255,255,255,0.2);vertical-align:middle;"></span>
            </button>
            <input type="text" value="${esc(item.label || '')}" placeholder="${nameLabel}" aria-label="${nameLabel}"
              class="form-input text-xs" data-volume-measure-action="rename" data-measurement-id="${esc(item.id)}"
              style="flex:1;min-width:0;width:50px;padding:2px 4px;background:rgba(0,0,0,0.2);border:1px solid var(--border-default);color:var(--text-primary);border-radius:4px;">
            <span style="white-space:nowrap;font-size:11px;color:var(--text-muted);">
              ${item.visible === false ? esc(this._t('hidden')) : this._fmtUm(item.distance)}
            </span>
            <span class="related-actions" style="display:flex;gap:2px;">
              <button class="btn btn-ghost btn-sm" type="button"
                data-volume-measure-action="toggle" data-measurement-id="${esc(item.id)}"
                title="${visLabel}" aria-label="${visLabel}" style="padding:2px;">
                <i data-lucide="${item.visible === false ? 'eye-off' : 'eye'}" aria-hidden="true"></i>
              </button>
              <button class="btn btn-ghost btn-sm" type="button"
                data-volume-measure-action="delete" data-measurement-id="${esc(item.id)}"
                title="${deleteLabel}" aria-label="${deleteLabel}" style="padding:2px;">
                <i data-lucide="trash-2" aria-hidden="true"></i>
              </button>
            </span>
          </div>
        `;
        }).join('')
        : esc(this._t('noMeasure'));
      this._ctx.ui.createIcons({ nodes: [list] });
    }

    // Status / live result area
    if (!this._draft.length) {
      this._setStatus(esc(this._t('clickTwo')));
      return;
    }
    if (this._draft.length === 1) {
      const p = this._draft[0].physicalUm;
      this._setStatus(`
        <div class="metric-tile"><small>${esc(this._t('pointA'))}</small><strong>${this._fmtUm(p.x)}, ${this._fmtUm(p.y)}, ${this._fmtUm(p.z)}</strong></div>
        <div class="text-xs text-muted">${esc(this._t('clickSecond'))}</div>
      `);
      return;
    }
    const [a, b] = this._draft.map(p => p.physicalUm);
    const dist   = this._dist3d(a, b);
    this._setStatus(`
      <div class="metric-grid">
        <div class="metric-tile"><small>${esc(this._t('distance'))}</small><strong>${this._fmtUm(dist)}</strong></div>
        <div class="metric-tile"><small>${esc(this._t('deltaZ'))}</small><strong>${this._fmtUm(Math.abs(a.z - b.z))}</strong></div>
      </div>
      <div class="text-xs text-muted">${esc(this._t('measuredBetween'))}</div>
    `);
  },

  _handleListEvent(e) {
    const action = e.target.closest('[data-volume-measure-action]')?.dataset.volumeMeasureAction;
    const id     = e.target.closest('[data-measurement-id]')?.dataset.measurementId;
    if (!action || !id) return;

    if (action === 'toggle' && e.type === 'click') {
      const item = this._measurements.find(r => r.id === id);
      if (!item) return;
      this._ctx.measurements.update('viewer', id, { visible: item.visible === false });
      this._measurements = this._ctx.measurements.list('viewer');
      this._ctx.viewer.setMeasurements(this._measurements);
      this._render();
    }
    if (action === 'delete' && e.type === 'click') {
      this._measurements = this._ctx.measurements.remove('viewer', id);
      this._ctx.viewer.setMeasurements(this._measurements);
      this._render();
    }
    if (action === 'rename' && e.type === 'change') {
      this._ctx.measurements.update('viewer', id, { label: e.target.value });
      this._measurements = this._ctx.measurements.list('viewer');
      this._ctx.viewer.setMeasurements(this._measurements);
      this._render();
    }
    if (action === 'toggle-color' && e.type === 'click') {
      const btn = e.target.closest('[data-volume-measure-action="toggle-color"]');
      if (btn) this._showColorPopup(id, btn);
    }
  },

  _showColorPopup(id, anchorEl) {
    this._closeColorPopup();
    const popup = document.createElement('div');
    popup.id = 'measure-color-popup-active';
    popup.style.cssText = 'position:fixed;background:var(--bg-surface,#222);border:1px solid var(--border-default, #444);border-radius:6px;padding:6px;z-index:99999;box-shadow:0 4px 12px rgba(0,0,0,0.5);display:flex;flex-direction:column;gap:4px;';
    for (const row of this.PALETTE) {
      const rowDiv = document.createElement('div');
      rowDiv.style.cssText = 'display:flex;gap:4px;';
      for (const color of row) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.style.cssText = `width:20px;height:20px;border-radius:4px;border:1px solid rgba(255,255,255,0.15);background:${color};padding:0;cursor:pointer;transition:transform 0.1s;`;
        btn.title = color;
        btn.onmouseover = () => btn.style.transform = 'scale(1.1)';
        btn.onmouseout  = () => btn.style.transform = 'scale(1)';
        btn.onclick = (e) => {
          e.stopPropagation();
          this._ctx.measurements.update('viewer', id, { color });
          this._measurements = this._ctx.measurements.list('viewer');
          this._ctx.viewer.setMeasurements(this._measurements);
          this._render();
          this._closeColorPopup();
        };
        rowDiv.appendChild(btn);
      }
      popup.appendChild(rowDiv);
    }
    document.body.appendChild(popup);
    const rect = anchorEl.getBoundingClientRect();
    popup.style.top  = `${rect.bottom + 4}px`;
    popup.style.left = `${rect.left}px`;
    requestAnimationFrame(() => {
      const pr = popup.getBoundingClientRect();
      if (pr.right > window.innerWidth) popup.style.left = `${rect.right - pr.width}px`;
    });
  },

  _closeColorPopup() {
    document.getElementById('measure-color-popup-active')?.remove();
  },

  // HTML escaping does not stop a second CSS declaration inside style="", and an older
  // core's store keeps a colour from a shared #state= link unchecked: hex only here.
  _safeColor(color) {
    const text = String(color || '');
    return /^#[0-9a-f]{3,8}$/i.test(text) ? text : '#ff4d4f';
  },

  _setStatus(html) {
    const node = document.getElementById('volume-measure-status');
    if (node) node.innerHTML = html;
  },

  _dist3d(a, b) {
    const dx = (a.x || 0) - (b.x || 0);
    const dy = (a.y || 0) - (b.y || 0);
    const dz = (a.z || 0) - (b.z || 0);
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  },

  _fmtUm(v) {
    if (!Number.isFinite(v)) return '—';
    return v >= 1000 ? `${(v / 1000).toFixed(3)} mm` : `${v.toFixed(2)} µm`;
  },

  // Teardown drops what is transient (pending pick, popup, listeners); the
  // measurements themselves are the user's data and stay in MeasurementStore —
  // only the Clear button and reset() erase them.
  dispose() {
    this._draft = [];
    this._closeColorPopup();
    this._listNode?.removeEventListener('click', this._onList);
    this._listNode?.removeEventListener('change', this._onList);
    this._clearNode?.removeEventListener('click', this._onClear);
    this._listNode = null; this._clearNode = null;
    try { this._ctx?.viewer?.onMeasurePoint?.(null); } catch (_) { /* viewer already gone */ }
  }
});
