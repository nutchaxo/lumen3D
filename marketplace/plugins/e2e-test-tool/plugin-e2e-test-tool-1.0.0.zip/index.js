LumenPlugin.register({
  async init() { this.btn = LumenPlugin.addButton({ label: LumenPlugin.t('title'), icon: 'check' }); },
  async activate() { LumenPlugin.toast('ok').catch(function () {}); return { active: false }; },
  dispose() {}
});
