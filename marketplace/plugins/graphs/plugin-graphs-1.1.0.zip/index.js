/* Graphs — index.js
 *
 * Live graphs of the dataset on screen. The user picks what goes on X and on Y
 * from the variables of the data the page holds; the plot follows every choice.
 *
 * MODEL. The data of a dataset is described as TABLES of rows and columns — a row
 * is one thing observed, a column one variable of it:
 *   voxels   (3d, live)  one row per voxel of a coarse level: x y z (µm and % of the
 *                        extent) and the intensity of every channel, read LOSSLESS
 *                        through ctx.data (never from the compressed display);
 *   pixels   (2d)        one row per pixel of the photograph: x y, R G B, luminance,
 *                        saturation, blue excess (B − R);
 *   cells    (live+tracking)  one row per tracked cell: lifetime, path, speed, …;
 *   obs      (live+tracking)  one row per cell and frame: t, x y z, speed, age,
 *                        distance from start, neighbours;
 *   msd      (live+tracking)  one row per cell and time lag: mean squared displacement;
 *   frames   (live)      one row per timepoint: the signal level of the acquisition.
 * A graph is a QUERY over one table: X (binned when continuous, one bar per
 * category otherwise), one or several Y variables, an aggregation of Y inside each
 * bin (mean, median, SD, min, max, sum, percentile, count, signal volume, share of
 * voxels above a threshold), an optional grouping variable (one series per
 * category) and a normalisation. Two numeric variables can also be drawn as a
 * density map (co-localisation, Pearson / Manders) or as raw points.
 *
 * CONTEXTS. On a page the plugin draws a panel over the canvas. In a Compare panel
 * it only ANSWERS the host (REQUEST_GRAPH_DATA / GRAPH_DATA): each panel scans its
 * own dataset. In the Compare host ('compare' context) it draws one drawer that
 * asks every panel for the same query and overlays the results, one colour per
 * dataset.
 *
 * QUERIES run in engine-worker.js (this file's engine, loaded alone there): a table
 * crosses to the worker once per build, each query sends its spec. A page queries
 * one at a time per caller, the newest waiting query replacing an older one; a table
 * built for a state that is gone (another timepoint) has its read aborted. Without a
 * worker, or once it failed, the same engine runs on the page.
 *
 * Plotly (3.5 MB) is fetched from the platform's vendor folder the first time a
 * plot is drawn, with the integrity digest the platform pins for it.
 */
(function () {
  'use strict';

  // ════════════════════════════════════════════════════════════════════
  // Constants
  // ════════════════════════════════════════════════════════════════════

  const ALL = '__all';                    // X token: one bin, a summary value per series
  const INT = '@int';                     // token: every channel-like variable of the table
  const AGGS = ['mean', 'median', 'min', 'max', 'std', 'p95', 'sum', 'count', 'measure', 'fraction'];
  const NEEDS_Y = new Set(['mean', 'median', 'min', 'max', 'std', 'p95', 'sum', 'fraction']);
  const COUNT_FAMILY = new Set(['count', 'measure', 'fraction']);
  const ROW_BUDGET = 6e6;                 // voxels read for the voxel table
  const CHANNEL_BUDGET = 18e6;            // voxels × channels
  const POINT_BUDGET = 20000;             // raw points drawn
  const MAX_SERIES = 24;
  const MAX_BINS = 400;
  const PIXEL_BUDGET = 2e6;
  const BIN_CACHE_ENTRIES = 4;            // X binnings kept per table (≤ 2 bytes per row each)

  // The platform's categorical palette (dataviz skill, validated), in its fixed
  // order: a colour follows the entity it was given to, never its rank.
  const PALETTE = {
    light: ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#6250d6', '#e34948'],
    dark: ['#3987e5', '#d95926', '#199e70', '#c98500', '#d55181', '#008300', '#9085e9', '#e66767']
  };
  const DASHES = ['solid', 'dash', 'dot', 'dashdot'];
  const SYMBOLS = ['circle', 'square', 'diamond', 'triangle-up'];
  const SURFACE = { light: '#fcfcfb', dark: '#1a1a19' };
  const PLOTLY_SRC = 'js/vendor/plotly.min.js';
  const PLOTLY_SRI = 'sha384-Hl48Kq2HifOWdXEjMsKo6qxqvRLTYqIGbvlENBmkHAxZKIGCXv43H6W1jA671RzC';

  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
  const slug = (s) => String(s ?? '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '');

  function gerr(code, message) {
    return Object.assign(new Error(message || code), { code });
  }

  // ════════════════════════════════════════════════════════════════════
  // Colour helpers (contrast of an entity's own colour against the surface)
  // ════════════════════════════════════════════════════════════════════

  function hexToRgb(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '').trim());
    if (!m) return null;
    const n = parseInt(m[1], 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function rgbToHex(rgb) {
    return '#' + rgb.map(v => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join('');
  }
  function luminance(rgb) {
    const f = (c) => { const s = c / 255; return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(rgb[0]) + 0.7152 * f(rgb[1]) + 0.0722 * f(rgb[2]);
  }
  function contrast(a, b) {
    const la = luminance(a), lb = luminance(b);
    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
  }
  /** A channel colour such as #00FF00 vanishes on a white page: pull it toward black
   *  (light page) or white (dark page) until it holds 3:1 against the surface. */
  function readable(hex, dark) {
    const rgb = hexToRgb(hex);
    if (!rgb) return null;
    const bg = hexToRgb(dark ? SURFACE.dark : SURFACE.light);
    const target = dark ? [255, 255, 255] : [0, 0, 0];
    let cur = rgb;
    for (let k = 0; k < 20 && contrast(cur, bg) < 3; k++) {
      cur = cur.map((v, i) => v + (target[i] - v) * 0.12);
    }
    return rgbToHex(cur);
  }
  /** A colour read from a dataset's metadata goes into a style attribute: only a hex
   *  colour passes, anything else (a `;` would add declarations) is dropped. */
  function safeColor(c) {
    const v = String(c ?? '').trim();
    return /^#[0-9a-f]{3,8}$/i.test(v) ? v : null;
  }
  function withAlpha(hex, a) {
    const rgb = hexToRgb(hex);
    return rgb ? `rgba(${rgb[0]},${rgb[1]},${rgb[2]},${a})` : hex;
  }

  // ════════════════════════════════════════════════════════════════════
  // Engine — pure: tables in, plain results out
  // ════════════════════════════════════════════════════════════════════
  //
  // table = { id, n, cols: { varId: TypedArray },
  //           lazy: { varId: () => TypedArray | { fill: 'axis', dims, axis, scale } },
  //           vars: [{ id, label, unit, kind: 'num'|'cat', dom?: [lo, hi], step?, bins?,
  //                    intensity?, ch?, color?, cats?: { names, colors } }],
  //           measureUnit, unitSize }
  // A categorical column holds the index of the category (negative / NaN = none).
  // A lazy column described by data (an axis) can be built wherever the table is, the
  // engine worker included; a function stays on the page that made it.

  const Engine = (() => {
    const binCaches = new WeakMap();      // table -> Map(binning key -> bins), dropped with the table

    function varOf(table, id) { return table.vars.find(v => v.id === id) || null; }

    /** Position of every row along one axis of a grid whose rows run x fastest, then
     *  y, then z: (index along the axis + 0.5) · scale, the centre of the voxel/pixel. */
    function fillAxis(desc) {
      const dx = desc.dims[0], dy = desc.dims[1] || 1, dz = desc.dims[2] || 1;
      const k = desc.axis, scale = desc.scale;
      const a = new Float32Array(dx * dy * dz);
      let i = 0;
      for (let z = 0; z < dz; z++) for (let y = 0; y < dy; y++) for (let x = 0; x < dx; x++) {
        a[i++] = ((k === 0 ? x : k === 1 ? y : z) + 0.5) * scale;
      }
      return a;
    }

    function colOf(table, id) {
      let c = table.cols[id];
      const lazy = !c && table.lazy ? table.lazy[id] : null;
      if (typeof lazy === 'function') c = table.cols[id] = lazy();
      else if (lazy && lazy.fill === 'axis') c = table.cols[id] = fillAxis(lazy);
      return c || null;
    }

    function minMax(col) {
      let lo = Infinity, hi = -Infinity;
      for (let i = 0; i < col.length; i++) {
        const v = col[i];
        if (v < lo) lo = v;
        if (v > hi) hi = v;
      }
      return lo <= hi ? [lo, hi] : [0, 1];
    }

    function intensityIds(table) { return table.vars.filter(v => v.ch).map(v => v.id); }

    /** Expand the @int / @int[k] tokens and drop what the table does not have. */
    function expandIds(table, ids) {
      const ints = intensityIds(table);
      const out = [];
      for (const id of ids || []) {
        if (id === INT) { out.push(...ints); continue; }
        const m = /^@int\[(\d+)\]$/.exec(id);
        if (m) { if (ints[+m[1]]) out.push(ints[+m[1]]); continue; }
        if (varOf(table, id)) out.push(id);
      }
      return [...new Set(out)];
    }

    /** The spec the engine will run: defaults filled in, unknown variables dropped,
     *  combinations that mean nothing turned into the nearest one that does. */
    function normalizeSpec(table, spec = {}) {
      const s = Object.assign({
        x: null, y: [], agg: 'mean', group: null, bins: 0, threshold: 0, signalOnly: false,
        band: false, normalize: 'none', yScale: 'linear', xScale: 'linear', xDomain: null, only: null
      }, spec);
      const nums = table.vars.filter(v => v.kind === 'num');
      s.y = Array.isArray(s.y) ? s.y : (s.y ? [s.y] : []);
      s.y = expandIds(table, s.y).filter(id => varOf(table, id).kind === 'num');
      s.threshold = clamp(Number(s.threshold) || 0, 0, 254);
      s.bins = Number.isFinite(+s.bins) && +s.bins >= 2 ? Math.min(MAX_BINS, Math.round(+s.bins)) : 0;
      if (s.agg !== 'points' && s.agg !== 'density' && !AGGS.includes(s.agg)) s.agg = 'mean';

      if (s.x === INT && !intensityIds(table).length) s.x = null;
      if (s.x === INT) {
        if (!COUNT_FAMILY.has(s.agg) || s.agg === 'fraction') s.agg = 'count';
        s.y = [];
      } else {
        const m = /^@int\[(\d+)\]$/.exec(s.x || '');
        if (m) s.x = intensityIds(table)[+m[1]] || null;
        if (s.x !== ALL && !(s.x && varOf(table, s.x))) s.x = table.defaults?.x || (nums[0] && nums[0].id) || null;
      }
      if (!s.x) throw gerr('NO_VARIABLE', 'the table has no variable to plot');

      const xv = s.x === ALL || s.x === INT ? null : varOf(table, s.x);
      if (s.agg === 'density' || s.agg === 'points') {
        if (!xv || xv.kind !== 'num') { s.agg = 'mean'; }
        else {
          s.y = s.y.filter(id => id !== s.x).slice(0, s.agg === 'density' ? 1 : 3);
          if (!s.y.length) {
            const alt = (table.defaults?.y || []).concat(nums.map(v => v.id)).find(id => id !== s.x && varOf(table, id)?.kind === 'num');
            if (alt) s.y = [alt]; else s.agg = 'mean';
          }
        }
      }
      if (NEEDS_Y.has(s.agg) && !s.y.length) {
        const dy = expandIds(table, table.defaults?.y || []).filter(id => id !== s.x);
        s.y = dy.length ? dy : nums.filter(v => v.id !== s.x).slice(0, 1).map(v => v.id);
        if (!s.y.length) throw gerr('NO_VARIABLE', 'no variable to aggregate');
      }
      if (s.group) {
        const gv = varOf(table, s.group);
        if (!gv || gv.kind !== 'cat' || s.group === s.x) s.group = null;
      }
      if (!['none', 'max', 'sum', 'first'].includes(s.normalize)) s.normalize = 'none';
      s.yScale = s.yScale === 'log' ? 'log' : 'linear';
      s.xScale = s.xScale === 'log' ? 'log' : 'linear';
      return s;
    }

    /** Bin index of every row for X. A table's columns never change, so the binning of
     *  one X is reused by every query that only changes Y, the aggregation, the group
     *  or the threshold (the slider). Callers never write into what this returns. */
    function makeBins(table, xid, spec) {
      if (xid === ALL) return { nb: 1, idx: null, centers: [''], cat: true, labels: [''], w: 1, lo: 0 };
      const ck = `${xid}|${spec.bins || 0}|${Array.isArray(spec.xDomain) ? spec.xDomain.join(',') : ''}`;
      let cache = binCaches.get(table);
      if (!cache) { cache = new Map(); binCaches.set(table, cache); }
      const hit = cache.get(ck);
      if (hit) { cache.delete(ck); cache.set(ck, hit); return hit; }
      const bins = binRows(table, xid, spec);
      cache.set(ck, bins);
      while (cache.size > BIN_CACHE_ENTRIES) cache.delete(cache.keys().next().value);
      return bins;
    }

    function binRows(table, xid, spec) {
      const xv = varOf(table, xid);
      const col = colOf(table, xid);
      if (!col) throw gerr('NO_VARIABLE', `no column ${xid}`);
      const n = table.n;
      if (xv.kind === 'cat') {
        const names = xv.cats.names;
        const nb = names.length;
        const idx = nb <= 0x7fff ? new Int16Array(n) : new Int32Array(n);
        for (let i = 0; i < n; i++) { const v = col[i]; idx[i] = v >= 0 && v < nb ? v | 0 : -1; }
        return { nb, idx, centers: names.slice(), cat: true, labels: names.slice(), w: 1, lo: 0, colors: xv.cats.colors || null };
      }
      let [lo, hi] = spec.xDomain || xv.dom || minMax(col);
      if (!(hi > lo)) hi = lo + 1;
      const step = xv.step > 0 ? xv.step : 0;
      const nSteps = step ? Math.round((hi - lo) / step) + 1 : 0;
      const want = clamp(spec.bins || xv.bins || 64, 2, MAX_BINS);
      // 'round': one bin per natural step (a plane, a frame, an intensity level);
      // 'group': a whole number of steps per bin, so every bin holds the same number of
      //          planes (counts and volumes are not a sawtooth of n and n + 1);
      // 'floor': a continuous variable cut in equal widths.
      let mode = 'floor';
      if (step && nSteps >= 2) mode = nSteps <= MAX_BINS && !(spec.bins && spec.bins < nSteps) ? 'round' : 'group';
      let nb, w, per = 1;
      if (mode === 'round') { nb = nSteps; w = step; }
      else if (mode === 'group') { per = Math.ceil(nSteps / want); nb = Math.ceil(nSteps / per); w = per * step; }
      else { nb = want; w = (hi - lo) / nb; }
      const idx = new Int16Array(n);                // nb ≤ MAX_BINS; −1 = outside
      if (mode === 'floor') {
        // Columns are Float32 and the domain is not: a value a Float32 ulp outside
        // [lo, hi] belongs to the end bin, not to nowhere.
        const tol = Math.max(Math.abs(lo), Math.abs(hi), w) * 2.4e-7;
        for (let i = 0; i < n; i++) {
          const v = col[i];
          let b = Math.floor((v - lo) / w);
          if (v >= hi - tol && v <= hi + tol) b = nb - 1;
          else if (b < 0 && v >= lo - tol) b = 0;
          idx[i] = b >= 0 && b < nb ? b : -1;      // NaN fails both tests
        }
      } else {
        for (let i = 0; i < n; i++) {
          const k = Math.round((col[i] - lo) / step);
          idx[i] = k >= 0 && k < nSteps ? (per === 1 ? k : (k / per) | 0) : -1;
        }
      }
      const centers = new Array(nb);
      for (let b = 0; b < nb; b++) {
        if (mode === 'round') centers[b] = lo + b * step;
        else if (mode === 'group') centers[b] = lo + ((b * per + Math.min(nSteps - 1, b * per + per - 1)) / 2) * step;
        else centers[b] = lo + (b + 0.5) * w;
      }
      return { nb, idx, centers, cat: false, labels: null, w, lo, round: mode === 'round' };
    }

    function accumulate(n, idx, nb, gcol, G, ycol, useThr, thr) {
      const K = G * nb;
      const tot = new Float64Array(K), cnt = new Float64Array(K), sum = new Float64Array(K), sum2 = new Float64Array(K);
      const mn = new Float64Array(K).fill(Infinity), mx = new Float64Array(K).fill(-Infinity);
      for (let i = 0; i < n; i++) {
        const b = idx ? idx[i] : 0;
        if (b < 0) continue;
        let g = 0;
        if (gcol) { g = gcol[i]; if (!(g >= 0 && g < G)) continue; g |= 0; }
        const k = g * nb + b;
        tot[k]++;
        if (ycol) {
          const y = ycol[i];
          if (y !== y) continue;
          if (useThr && !(y > thr)) continue;
          cnt[k]++; sum[k] += y; sum2[k] += y * y;
          if (y < mn[k]) mn[k] = y;
          if (y > mx[k]) mx[k] = y;
        } else cnt[k]++;
      }
      return { tot, cnt, sum, sum2, mn, mx };
    }

    /** Nearest-rank quantile (sorted[floor(q·(c−1))]) per bin and group. */
    function quantile(n, idx, nb, gcol, G, ycol, q, cnt, useThr, thr) {
      const K = G * nb;
      const out = new Float64Array(K).fill(NaN);
      const walk = (fn) => {
        for (let i = 0; i < n; i++) {
          const b = idx ? idx[i] : 0;
          if (b < 0) continue;
          let g = 0;
          if (gcol) { g = gcol[i]; if (!(g >= 0 && g < G)) continue; g |= 0; }
          const y = ycol[i];
          if (y !== y || (useThr && !(y > thr))) continue;
          fn(g * nb + b, y);
        }
      };
      if (ycol instanceof Uint8Array || ycol instanceof Uint8ClampedArray) {
        const hist = new Uint32Array(K * 256);
        walk((k, y) => { hist[k * 256 + y]++; });
        for (let k = 0; k < K; k++) {
          const c = cnt[k];
          if (!c) continue;
          const rank = Math.floor(q * (c - 1));
          let acc = 0;
          for (let v = 0; v < 256; v++) { acc += hist[k * 256 + v]; if (acc > rank) { out[k] = v; break; } }
        }
        return out;
      }
      const off = new Float64Array(K + 1);
      for (let k = 0; k < K; k++) off[k + 1] = off[k] + cnt[k];
      const vals = new Float32Array(off[K]);
      const cur = off.slice(0, K);
      walk((k, y) => { vals[cur[k]++] = y; });
      for (let k = 0; k < K; k++) {
        const c = cnt[k];
        if (!c) continue;
        const seg = vals.subarray(off[k], off[k + 1]);
        seg.sort();
        out[k] = seg[Math.floor(q * (c - 1))];
      }
      return out;
    }

    function seriesColor(table, yv, gv, g) {
      if (gv) return gv.cats.colors?.[g] || null;
      return yv?.color || null;
    }

    /** → [normalised values, divisor] (divisor 1 when nothing was applied). */
    function normalizeSeries(y, mode) {
      if (mode === 'none') return [y, 1];
      let base = NaN;
      if (mode === 'max') { base = -Infinity; for (const v of y) if (v !== null && v > base) base = v; }
      else if (mode === 'sum') { base = 0; for (const v of y) if (v !== null) base += v; }
      else if (mode === 'first') { base = NaN; for (const v of y) if (v !== null && v !== 0) { base = v; break; } }
      if (!(base > 0)) return [y, 1];           // a zero or negative base would flip signs or divide by nothing
      return [y.map(v => (v === null ? null : v / base)), base];
    }

    function computeXY(table, s) {
      const n = table.n;
      const allInts = intensityIds(table);
      const keep = Array.isArray(s.only) ? allInts.filter(id => s.only.includes(id)) : [];
      const xids = s.x === INT ? (keep.length ? keep : allInts) : [s.x];
      const gv = s.group ? varOf(table, s.group) : null;
      const gcol = gv ? colOf(table, gv.id) : null;
      const G = gv ? gv.cats.names.length : 1;
      const series = [];
      const notes = [];
      let first = null;

      const yList = s.x === INT ? [null] : (s.y.length ? s.y : [null]);
      for (const xid of xids) {
        const bins = makeBins(table, xid, s);
        if (!first) first = { bins, xv: xid === ALL ? null : varOf(table, xid) };
        const xv = xid === ALL ? null : varOf(table, xid);
        for (const yid of yList) {
          const yv = yid ? varOf(table, yid) : null;
          const ycol = yid ? colOf(table, yid) : null;
          const useThr = Boolean(yv && yv.intensity && (COUNT_FAMILY.has(s.agg) || s.signalOnly));
          const acc = accumulate(n, bins.idx, bins.nb, gcol, G, ycol, useThr, s.threshold);
          let q = null;
          if (s.agg === 'median' || s.agg === 'p95') {
            q = quantile(n, bins.idx, bins.nb, gcol, G, ycol, s.agg === 'median' ? 0.5 : 0.95, acc.cnt, useThr, s.threshold);
          }
          for (let g = 0; g < G; g++) {
            const y = new Array(bins.nb), sd = new Array(bins.nb), cn = new Array(bins.nb);
            let groupRows = 0;
            for (let b = 0; b < bins.nb; b++) {
              const k = g * bins.nb + b;
              const c = acc.cnt[k];
              cn[b] = c;
              let v = null;
              switch (s.agg) {
                case 'count': v = c; break;
                case 'measure': v = c * (table.unitSize || 1); break;
                case 'fraction': v = acc.tot[k] ? (c / acc.tot[k]) * 100 : null; break;
                case 'sum': v = c ? acc.sum[k] : null; break;
                case 'min': v = c ? acc.mn[k] : null; break;
                case 'max': v = c ? acc.mx[k] : null; break;
                case 'mean': v = c ? acc.sum[k] / c : null; break;
                case 'std': v = c ? Math.sqrt(Math.max(0, acc.sum2[k] / c - (acc.sum[k] / c) ** 2)) : null; break;
                case 'median': case 'p95': v = c ? q[k] : null; break;
                default: v = null;
              }
              groupRows += acc.tot[k];
              y[b] = v;
              sd[b] = s.agg === 'mean' && c ? Math.sqrt(Math.max(0, acc.sum2[k] / c - (acc.sum[k] / c) ** 2)) : null;
            }
            if (G > 1 && !groupRows) continue;
            if (series.length >= MAX_SERIES) { if (!notes.includes('series-capped')) notes.push('series-capped'); continue; }
            const parts = [];
            // With one Y the axis title already names it: the legend only says which group.
            if (s.x === INT) parts.push(xv.label);
            else if (yv && (!gv || s.y.length > 1)) parts.push(yv.label);
            if (gv) parts.push(gv.cats.names[g]);
            const [normed, base] = normalizeSeries(y, s.normalize);
            series.push({
              label: parts.join(' · ') || (COUNT_FAMILY.has(s.agg) ? '' : (yv?.label || '')),
              // Several Y variables: the colour is the channel's (the entity the eye follows),
              // and the groups of one channel differ by dash. One Y: the group's colour.
              color: (s.x === INT ? xv.color : (s.y.length > 1 && yv && yv.color ? yv.color : seriesColor(table, yv, gv, g))) || null,
              gi: gv ? g : null,
              multiY: s.y.length > 1,
              varId: s.x === INT ? xid : yid,
              group: gv ? gv.cats.names[g] : null,
              x: bins.cat ? bins.labels.slice() : bins.centers.slice(),
              y: normed,
              sd: s.band && s.agg === 'mean' ? sd.map(v => (v === null ? null : v / base)) : null,
              n: cn
            });
          }
        }
      }
      const xv0 = first.xv;
      return {
        kind: first.bins.cat ? 'bar' : 'xy',
        x: xv0 ? { id: s.x === INT ? INT : xv0.id, label: s.x === INT ? null : xv0.label, unit: xv0.unit || '', cat: first.bins.cat } : { id: ALL, label: null, unit: '', cat: true },
        y: yAxisInfo(table, s, s.x === INT ? null : (s.y.length === 1 ? varOf(table, s.y[0]) : null)),
        series, notes
      };
    }

    function yAxisInfo(table, s, yv) {
      const unit = s.agg === 'measure' ? (table.measureUnit || '')
        : s.agg === 'fraction' ? '%'
        : s.agg === 'count' ? ''
        : (s.normalize !== 'none' ? '' : (yv?.unit || ''));
      return { agg: s.agg, normalize: s.normalize, unit, label: yv ? yv.label : null, many: s.y.length > 1, intensity: s.y.length > 0 && s.y.every(id => varOf(table, id).intensity) };
    }

    function computePoints(table, s) {
      const xv = varOf(table, s.x);
      const xcol = colOf(table, s.x);
      const gv = s.group ? varOf(table, s.group) : null;
      const gcol = gv ? colOf(table, gv.id) : null;
      const stride = Math.max(1, Math.ceil(table.n / POINT_BUDGET));
      const series = [];
      for (const yid of s.y) {
        const yv = varOf(table, yid);
        const ycol = colOf(table, yid);
        const G = gv ? gv.cats.names.length : 1;
        const bucket = Array.from({ length: G }, () => ({ x: [], y: [] }));
        for (let i = 0; i < table.n; i++) {
          // Every stride-th row would alias with the voxel / frame layout (an X scatter
          // collapsing to a few columns): keep a pseudo-random 1 in `stride` instead.
          if (stride > 1 && (Math.imul(i, 2654435761) >>> 0) % stride !== 0) continue;
          const a = xcol[i], b = ycol[i];
          if (a !== a || b !== b) continue;
          let g = 0;
          if (gcol) { g = gcol[i]; if (!(g >= 0 && g < G)) continue; g |= 0; }
          bucket[g].x.push(a); bucket[g].y.push(b);
        }
        bucket.forEach((bk, g) => {
          if (!bk.x.length) return;
          series.push({
            label: [(!gv || s.y.length > 1) ? yv.label : null, gv ? gv.cats.names[g] : null].filter(Boolean).join(' · '),
            color: gv ? (gv.cats.colors?.[g] || null) : (yv.color || null),
            varId: yid, group: gv ? gv.cats.names[g] : null, x: bk.x, y: bk.y, sd: null, n: null
          });
        });
      }
      return {
        kind: 'points',
        x: { id: xv.id, label: xv.label, unit: xv.unit || '', cat: false },
        y: { agg: 'points', label: s.y.length === 1 ? varOf(table, s.y[0]).label : null, unit: s.y.length === 1 ? (varOf(table, s.y[0]).unit || '') : '', many: s.y.length > 1 },
        series, notes: stride > 1 ? ['subsampled'] : [], stride
      };
    }

    function computeDensity(table, s) {
      const xv = varOf(table, s.x), yv = varOf(table, s.y[0]);
      const xc = colOf(table, xv.id), yc = colOf(table, yv.id);
      const n = table.n;
      const nb = clamp(s.bins || 64, 8, 128);
      const [xl, xh0] = s.xDomain || xv.dom || minMax(xc);
      const [yl, yh0] = yv.dom || minMax(yc);
      const xh = xh0 > xl ? xh0 : xl + 1, yh = yh0 > yl ? yh0 : yl + 1;
      const wx = (xh - xl) / nb, wy = (yh - yl) / nb;
      const z = new Float64Array(nb * nb);
      const tx = Math.max(Math.abs(xl), Math.abs(xh), wx) * 2.4e-7, ty = Math.max(Math.abs(yl), Math.abs(yh), wy) * 2.4e-7;
      const both = Boolean(xv.intensity && yv.intensity);
      const thr = s.threshold;
      let m = 0, sx = 0, sy = 0, sxx = 0, syy = 0, sxy = 0;
      let mx = 0, my = 0, sxIn = 0, syIn = 0, sxT = 0, syT = 0;
      for (let i = 0; i < n; i++) {
        const a = xc[i], b = yc[i];
        if (a !== a || b !== b) continue;
        let bx = Math.floor((a - xl) / wx), by = Math.floor((b - yl) / wy);
        if (bx === nb && a <= xh + tx) bx = nb - 1; else if (bx < 0 && a >= xl - tx) bx = 0;
        if (by === nb && b <= yh + ty) by = nb - 1; else if (by < 0 && b >= yl - ty) by = 0;
        if (bx >= 0 && bx < nb && by >= 0 && by < nb) z[by * nb + bx]++;
        // Manders: M1 = Σ a over the voxels where b is above its threshold / Σ a over ALL
        // voxels (M2 the other way round) — textbook denominators, so a threshold does
        // not change what the fraction is a fraction of.
        if (both) {
          sxT += a; syT += b;
          if (b > thr) sxIn += a;
          if (a > thr) syIn += b;
        }
        // Pearson over the voxels where either channel carries signal: the shared
        // background would otherwise dominate the correlation.
        if (both && !(a > thr || b > thr)) continue;
        m++; sx += a; sy += b; sxx += a * a; syy += b * b; sxy += a * b;
      }
      let pearson = null;
      if (m > 2) {
        const vx = sxx - sx * sx / m, vy = syy - sy * sy / m;
        if (vx > 0 && vy > 0) pearson = (sxy - sx * sy / m) / Math.sqrt(vx * vy);
      }
      const rows = Array.from({ length: nb }, (_, r) => Array.from(z.subarray(r * nb, (r + 1) * nb)));
      return {
        kind: 'heat',
        x: { id: xv.id, label: xv.label, unit: xv.unit || '', cat: false },
        y: { agg: 'density', label: yv.label, unit: yv.unit || '' },
        heat: {
          x: Array.from({ length: nb }, (_, i) => xl + (i + 0.5) * wx),
          y: Array.from({ length: nb }, (_, i) => yl + (i + 0.5) * wy),
          z: rows,
          xLabel: xv.label, yLabel: yv.label, xUnit: xv.unit || '', yUnit: yv.unit || '',
          stats: { n: m, pearson, m1: both && sxT > 0 ? sxIn / sxT : null, m2: both && syT > 0 ? syIn / syT : null, both }
        },
        series: [], notes: []
      };
    }

    function compute(table, spec) {
      const s = normalizeSpec(table, spec);
      if (!table.n) throw gerr('NO_DATA', 'the table is empty');
      let result;
      if (s.agg === 'density') result = computeDensity(table, s);
      else if (s.agg === 'points') result = computePoints(table, s);
      else result = computeXY(table, s);
      if (Array.isArray(table.notes) && table.notes.length) result.notes = [...new Set([...(result.notes || []), ...table.notes])];
      result.spec = s;
      result.table = table.id;
      result.measureUnit = table.measureUnit || '';
      return result;
    }

    function csvCell(v) {
      if (v === null || v === undefined || (typeof v === 'number' && !Number.isFinite(v))) return '';
      let s = String(v);
      // A text cell a spreadsheet would run as a formula (a dataset, channel or region name
      // is operator data): the leading apostrophe makes it plain text.
      if (typeof v === 'string' && /^[=+\-@\t\r]/.test(s)) s = `'${s}`;
      return /[",\n\r;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    }

    /** The plotted numbers, long format: one row per point of a series (per cell of a map). */
    function toCsv(result) {
      const lines = [];
      if (result.heats || result.heat) {
        lines.push(['dataset', 'x', 'y', 'count'].map(csvCell).join(','));
        for (const h of result.heats || [{ ds: null, ...result.heat }]) {
          h.z.forEach((row, r) => row.forEach((c, i) => {
            if (c) lines.push([csvCell(h.ds?.name || ''), csvCell(h.x[i]), csvCell(h.y[r]), csvCell(c)].join(','));
          }));
        }
        return lines.join('\n') + '\n';
      }
      lines.push(['dataset', 'series', result.x?.label || 'x', 'y', 'sd', 'n'].map(csvCell).join(','));
      for (const s of result.series) {
        s.x.forEach((x, i) => lines.push([
          csvCell(s.ds?.name || ''), csvCell(s.label), csvCell(x), csvCell(s.y[i]),
          csvCell(s.sd ? s.sd[i] : null), csvCell(s.n ? s.n[i] : null)
        ].join(',')));
      }
      return lines.join('\n') + '\n';
    }

    /** Throws NO_VARIABLE when the spec names a variable the table does not have. normalizeSpec
     *  repairs such a spec with the table's defaults — right for a page, wrong in Compare,
     *  where that panel would answer another question than the others. `table` needs only
     *  `vars`. The @int tokens are not variables (the caller resolves or the table expands). */
    function checkSpec(table, spec) {
      const ids = new Set(table.vars.map(v => v.id));
      const isToken = (id) => id === INT || id === ALL || /^@int\[\d+\]$/.test(id);
      const missing = [];
      const need = (id) => { if (typeof id === 'string' && id && !isToken(id) && !ids.has(id)) missing.push(id); };
      if (spec && typeof spec === 'object') {
        need(spec.x);
        if (Array.isArray(spec.y)) spec.y.forEach(need);
        need(spec.group);
      }
      if (missing.length) throw gerr('NO_VARIABLE', `the table has no variable ${missing.join(', ')}`);
    }

    return { varOf, colOf, fillAxis, normalizeSpec, checkSpec, makeBins, compute, toCsv, intensityIds, expandIds, ALL, INT };
  })();

  // engine-worker.js loads this file for the engine alone: nothing below runs there.
  if (typeof PluginRegistry === 'undefined' && typeof importScripts === 'function') {
    self.GraphsEngine = Engine;
    return;
  }

  /** The channel variables every dataset of a comparison has (all of a lone dataset's). */
  function sharedChannels(tb) {
    const ints = tb.vars.filter(v => v.ch);
    if (!(tb.total > 1)) return ints.map(v => v.id);
    return ints.filter(v => v.haveCount === tb.total).map(v => v.id);
  }

  /** What the chips show as "every channel": the shared ones, or — when no channel is
   *  shared — all of them, each dataset then drawing its own. */
  function commonChannels(tb) {
    const shared = sharedChannels(tb);
    return shared.length ? shared : tb.vars.filter(v => v.ch).map(v => v.id);
  }

  /** The spec a Compare round sends to every panel: "every channel" and "@int[k]" become the
   *  shared channels' ids, which are the same in every panel. With no shared channel the
   *  "every channel" token stays (each panel expands its own) and an "@int[k]" cannot be
   *  resolved (`unresolved`). */
  function specForPanels(spec, tb) {
    const shared = tb ? sharedChannels(tb) : [];
    let unresolved = false;
    const nth = (id) => {
      const m = /^@int\[(\d+)\]$/.exec(typeof id === 'string' ? id : '');
      if (!m) return id;
      if (!shared[+m[1]]) unresolved = true;
      return shared[+m[1]] || id;
    };
    const y = (spec.y || []).flatMap(id => (id === INT ? (shared.length ? shared : [INT]) : [nth(id)]));
    return { sent: { ...spec, x: nth(spec.x), y, only: spec.x === INT && shared.length ? shared : null }, unresolved };
  }

  /** Names of datasets that differ in one token (…-E8-Em3-… / …-E8-Em6-…): keep what differs. */
  function shortNames(names) {
    if (names.length < 2) return names.slice();
    const toks = names.map(n => String(n).split('-'));
    let pre = 0;
    while (toks.every(t => t.length > pre + 1 && t[pre] === toks[0][pre])) pre++;
    let suf = 0;
    while (toks.every(t => t.length - suf > pre + 1 && t[t.length - 1 - suf] === toks[0][toks[0].length - 1 - suf])) suf++;
    const out = toks.map(t => t.slice(pre, t.length - suf).join('-'));
    return out.every(Boolean) && new Set(out).size === out.length ? out : names.slice();
  }

  // ════════════════════════════════════════════════════════════════════
  // Plot — a result (one dataset or several) as Plotly traces
  // ════════════════════════════════════════════════════════════════════

  function axisTitle(label, unit) {
    return unit ? `${label} (${unit})` : label;
  }

  /** Plotly's `separators` (decimal then thousands) for a language: 0,25 in French, 0.25 in English. */
  function separatorsFor(lang) {
    try {
      const parts = new Intl.NumberFormat(lang || undefined).formatToParts(1234567.5);
      const dec = (parts.find(p => p.type === 'decimal') || {}).value || '.';
      const grp = (parts.find(p => p.type === 'group') || {}).value || ',';
      return dec + grp;
    } catch (_) { return '.,'; }
  }

  /** (value, digits) → text in the language's own number format. */
  function numberFormatter(lang) {
    return (v, d) => {
      try { return v.toLocaleString(lang || undefined, { minimumFractionDigits: d, maximumFractionDigits: d }); }
      catch (_) { return v.toFixed(d); }
    };
  }

  /** A binary data: URL as a Blob, without fetch(): the page's CSP (connect-src 'self') refuses
   *  fetch of a data: URL, which is how Plotly hands over an image. */
  function dataUrlToBlob(url) {
    const m = /^data:([^;,]*)(;base64)?,([\s\S]*)$/.exec(String(url));
    if (!m) throw new Error('not a data URL');
    const bin = m[2] ? atob(m[3]) : decodeURIComponent(m[3]);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new Blob([bytes], { type: m[1] || 'application/octet-stream' });
  }

  function yTitle(result, t) {
    const y = result.y || {};
    const unit = y.unit || '';
    let base;
    if (y.agg === 'count') base = t('y_count');
    else if (y.agg === 'measure') base = t('y_measure', { what: result.measureUnit === 'µm²' || result.measureUnit === 'px²' ? t('area') : t('volume') });
    else if (y.agg === 'fraction') base = t('y_fraction');
    else if (y.agg === 'points' || y.agg === 'density') base = y.label || '';
    else if (y.agg === 'mean') base = y.label && !y.many ? y.label : (y.intensity ? t('var_intensity') : t('agg_mean'));
    else base = t(`agg_${y.agg}`) + (y.label && !y.many ? ` · ${y.label}` : (y.intensity ? ` · ${t('var_intensity')}` : ''));
    if (y.normalize && y.normalize !== 'none') base += ` (${t(`norm_${y.normalize}`)})`;
    base = base.charAt(0).toUpperCase() + base.slice(1);
    return axisTitle(base, unit);
  }

  /** Plotly { data, layout } for a result. `o`: { dark, t, text, grid, colorBy,
   *  multi, cursorX, cursorLabel, spec }. Pure: no DOM, no Plotly. */
  function buildPlot(result, o) {
    const t = o.t;
    const dark = Boolean(o.dark);
    const pal = dark ? PALETTE.dark : PALETTE.light;
    const spec = result.spec || o.spec || {};
    const nf = o.nf || ((v, d) => v.toFixed(d));
    const layout = {
      margin: { t: 14, l: 58, r: 16, b: 46 },
      paper_bgcolor: 'rgba(0,0,0,0)',
      plot_bgcolor: 'rgba(0,0,0,0)',
      font: { color: o.text || (dark ? '#c3c2b7' : '#52514e'), size: 11 },
      showlegend: false,
      hovermode: 'closest',
      autosize: true
    };
    if (o.separators) layout.separators = o.separators;
    const grid = o.grid || (dark ? '#2f2f2d' : '#e3e2dd');
    const data = [];

    if (result.kind === 'heat') {
      const heats = result.heats || [{ ...result.heat, ds: null }];
      const N = heats.length;
      const rows = N > 2 ? 2 : 1;
      const cols = Math.ceil(N / rows);
      const gap = 0.06;
      layout.annotations = [];
      heats.forEach((h, i) => {
        const r = Math.floor(i / cols), c = i % cols;
        const ax = i === 0 ? '' : String(i + 1);
        const xd = [c / cols + (c ? gap / 2 : 0), (c + 1) / cols - (c < cols - 1 ? gap / 2 : 0)];
        const yd = [1 - (r + 1) / rows + (r < rows - 1 ? gap / 2 : 0), 1 - r / rows - (r ? gap / 2 : 0) - (N > 1 ? 0.07 : 0)];
        const logZ = spec.yScale === 'log';
        data.push({
          type: 'heatmap', x: h.x, y: h.y,
          z: logZ ? h.z.map(row => row.map(v => Math.log10(1 + v))) : h.z,
          customdata: h.z, xaxis: 'x' + ax, yaxis: 'y' + ax,
          colorscale: dark ? [[0, '#1a1a19'], [0.35, '#1f4f8f'], [1, '#8ec0ff']] : [[0, '#f4f7fc'], [0.35, '#9cc2f0'], [1, '#0b3a8a']],
          showscale: i === N - 1,
          colorbar: i === N - 1 ? { title: { text: logZ ? 'log₁₀(1+n)' : 'n', side: 'right' }, thickness: 10, len: 0.8 } : undefined,
          hovertemplate: `${escapeHtml(h.xLabel)}: %{x:.3g}<br>${escapeHtml(h.yLabel)}: %{y:.3g}<br>n = %{customdata}<extra></extra>`
        });
        layout['xaxis' + ax] = { domain: xd, anchor: 'y' + ax, title: { text: escapeHtml(axisTitle(h.xLabel, h.xUnit)), standoff: 6 }, gridcolor: grid, zeroline: false };
        layout['yaxis' + ax] = { domain: yd, anchor: 'x' + ax, title: { text: escapeHtml(axisTitle(h.yLabel, h.yUnit)), standoff: 6 }, gridcolor: grid, zeroline: false };
        const st = h.stats;
        const bits = [];
        if (h.ds) bits.push(`<b>${escapeHtml(h.ds.name)}</b>`);
        if (st && st.pearson !== null && st.pearson !== undefined) bits.push(`r = ${nf(st.pearson, 3)}`);
        if (st && st.both && st.m1 !== null) bits.push(`M1 = ${nf(st.m1, 2)}, M2 = ${st.m2 === null ? '–' : nf(st.m2, 2)}`);
        if (bits.length) {
          layout.annotations.push({
            xref: 'paper', yref: 'paper', x: xd[0], y: yd[1] + (N > 1 ? 0.045 : 0.0), xanchor: 'left', yanchor: 'bottom',
            text: bits.join(' · '), showarrow: false, font: { size: 11, color: layout.font.color }
          });
        }
      });
      layout.margin.t = N > 1 ? 24 : 26;
      return { data, layout };
    }

    const series = result.series;
    const multi = Boolean(o.multi);
    const colorBy = multi ? (o.colorBy || 'dataset') : 'series';
    const colorOf = (s, i) => {
      if (multi && colorBy === 'dataset' && s.ds) return pal[s.ds.slot % pal.length];
      const own = s.color ? readable(s.color, dark) : null;
      return own || pal[i % pal.length];
    };
    const dashOf = (s) => {
      if (!multi) return s.multiY && s.gi !== null && s.gi !== undefined ? DASHES[s.gi % DASHES.length] : 'solid';
      if (colorBy === 'dataset') return DASHES[(s.ds?.local || 0) % DASHES.length];
      return DASHES[(s.ds?.slot || 0) % DASHES.length];
    };
    // Several series on one dataset differ by marker as well as by colour (red / green must not be the only cue).
    const symOf = (s, i) => SYMBOLS[(((multi ? (colorBy === 'dataset' ? s.ds?.local : s.ds?.slot) : (series.length > 1 ? i : 0)) || 0)) % SYMBOLS.length];

    const logY = spec.yScale === 'log';
    const logX = spec.xScale === 'log' && result.kind !== 'bar';
    const pos = (v) => (logY ? (v !== null && v > 0 ? v : null) : v);

    series.forEach((s, i) => {
      const color = colorOf(s, i);
      // Plotly draws a subset of HTML in names and titles (links included): text from
      // a dataset, a channel or a region is escaped.
      const name = escapeHtml(s.label || (result.y?.label || ''));
      const y = s.y.map(pos);
      if (result.kind === 'bar') {
        data.push({
          type: 'bar', name, x: s.x.map(v => (typeof v === 'string' ? escapeHtml(v) : v)), y, marker: { color, line: { color: dark ? SURFACE.dark : SURFACE.light, width: 2 } },
          error_y: s.sd ? { type: 'data', array: s.sd.map(v => v || 0), visible: true, color: layout.font.color, thickness: 1, width: 3 } : undefined,
          hovertemplate: `${name}<br>%{x}: %{y:.4g}<extra></extra>`
        });
        return;
      }
      if (result.kind === 'points') {
        data.push({
          type: s.x.length > 4000 ? 'scattergl' : 'scatter', mode: 'markers', name,
          x: logX ? s.x.map(v => (v > 0 ? v : null)) : s.x, y,
          marker: { color, size: 5, opacity: 0.55, symbol: symOf(s, i) },
          hovertemplate: `${name}<br>%{x:.4g}, %{y:.4g}<extra></extra>`
        });
        return;
      }
      const dash = dashOf(s);
      if (s.sd) {
        const hi = s.y.map((v, k) => (v === null || s.sd[k] === null ? null : pos(v + s.sd[k])));
        const lo = s.y.map((v, k) => (v === null || s.sd[k] === null ? null : pos(v - s.sd[k])));
        data.push({ type: 'scatter', mode: 'lines', x: s.x, y: hi, line: { width: 0 }, hoverinfo: 'skip', showlegend: false, legendgroup: name });
        data.push({ type: 'scatter', mode: 'lines', x: s.x, y: lo, line: { width: 0 }, fill: 'tonexty', fillcolor: withAlpha(color, 0.16), hoverinfo: 'skip', showlegend: false, legendgroup: name });
      }
      const dense = s.x.length > 60;
      data.push({
        type: 'scatter', mode: dense ? 'lines' : 'lines+markers', name, legendgroup: name,
        x: logX ? s.x.map(v => (v > 0 ? v : null)) : s.x, y, connectgaps: false,
        line: { color, width: 2, dash },
        marker: { color, size: 7, symbol: symOf(s, i), line: { color: dark ? SURFACE.dark : SURFACE.light, width: 2 } },
        hovertemplate: `${name}<br>%{x:.4g}: %{y:.4g}<extra></extra>`
      });
    });

    const visible = data.filter(d => d.showlegend !== false && d.hoverinfo !== 'skip').length;
    layout.showlegend = visible > 1;
    layout.legend = { orientation: 'h', y: -0.28, x: 0, font: { size: 11 } };
    layout.hovermode = result.kind === 'xy' ? 'x unified' : 'closest';
    if (result.kind === 'bar') layout.barmode = 'group';
    const xl = result.x?.id === INT ? t('var_intensity') : (result.x?.label ? axisTitle(result.x.label, result.x.unit) : '');
    layout.xaxis = {
      title: { text: escapeHtml(xl), standoff: 6 }, gridcolor: grid, zeroline: false, type: result.kind === 'bar' ? 'category' : (logX ? 'log' : 'linear'),
      showticklabels: !(result.x?.id === ALL)
    };
    layout.yaxis = { title: { text: escapeHtml(yTitle(result, t)), standoff: 6 }, gridcolor: grid, zeroline: false, type: logY ? 'log' : 'linear', rangemode: logY ? undefined : 'tozero' };
    if (result.y?.agg === 'mean' || result.y?.agg === 'median' || result.y?.agg === 'min' || result.y?.agg === 'max') layout.yaxis.rangemode = 'normal';
    if (result.kind === 'points') layout.yaxis.rangemode = 'normal';
    if (isNum(o.cursorX) && result.kind === 'xy') {
      layout.shapes = [{ type: 'line', xref: 'x', yref: 'paper', x0: o.cursorX, x1: o.cursorX, y0: 0, y1: 1, line: { color: layout.font.color, width: 1, dash: 'dot' } }];
      layout.annotations = [{ xref: 'x', yref: 'paper', x: o.cursorX, y: 1, text: escapeHtml(o.cursorLabel || ''), showarrow: false, yanchor: 'bottom', font: { size: 10, color: layout.font.color } }];
      layout.margin.t = 26;
    }
    return { data, layout };
  }

  function escapeHtml(s) {
    return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ════════════════════════════════════════════════════════════════════
  // Sources — what each kind of page can tabulate
  // ════════════════════════════════════════════════════════════════════
  //
  // A source has a cheap `schema` (the variables, known from the metadata alone, so
  // the pickers appear at once) and an async `build` (the data, which may read the
  // volume). `key()` names the state the table depends on; a new key rebuilds it.

  function dtOf(meta) {
    const v = Number(meta?.timeline?.intervalMinutes);
    return v > 0 ? { dt: v, unit: 'min' } : { dt: 1, unit: 'frame' };
  }

  function channelVars(meta, t, n, opts = {}) {
    const used = new Set();
    const list = Array.isArray(meta?.channels) && meta.channels.length ? meta.channels : Array.from({ length: n }, (_, i) => ({ name: `Ch ${i + 1}` }));
    return Array.from({ length: n }, (_, c) => {
      const ch = list[c] || {};
      const name = ch.name || `Ch ${c + 1}`;
      let id = (opts.prefix || 'ch_') + (slug(name) || String(c));
      while (used.has(id)) id += c;
      used.add(id);
      return { id, label: name, unit: '', kind: 'num', dom: [0, 255], step: 1, bins: 64, intensity: true, ch: true, color: safeColor(ch.color), channelIndex: c };
    });
  }

  function positionVars(t, units) {
    const mk = (axis, k) => ({ id: axis, label: t(`var_${axis}`), unit: units, kind: 'num', pos: true, axis: k });
    const pc = (axis, k) => ({ id: axis + 'r', label: t(`var_${axis}r`), unit: '', kind: 'num', dom: [0, 100], bins: 50, pos: true, axis: k, rel: true });
    return [mk('x', 0), mk('y', 1), mk('z', 2), pc('x', 0), pc('y', 1), pc('z', 2)];
  }

  /** The distance measurements of the page that can be sampled: two picked points in µm. */
  function measurementLines(ctx) {
    let list = [];
    try { list = ctx.measurements && ctx.measurements.list ? ctx.measurements.list('viewer') : []; } catch (_) { list = []; }
    const out = [];
    const ok = (q) => q && isNum(q.x) && isNum(q.y) && isNum(q.z);
    for (const m of Array.isArray(list) ? list : []) {
      if (!m || m.visible === false || !Array.isArray(m.points) || m.points.length !== 2) continue;
      const a = m.points[0] && m.points[0].physicalUm, b = m.points[1] && m.points[1].physicalUm;
      if (!ok(a) || !ok(b)) continue;
      out.push({
        id: String(m.id || out.length),
        name: typeof m.label === 'string' && m.label ? m.label.slice(0, 80) : `#${out.length + 1}`,
        color: safeColor(m.color),
        a: [a.x, a.y, a.z], b: [b.x, b.y, b.z]
      });
      if (out.length >= 12) break;
    }
    return out;
  }

  const lineSignature = (ctx) => measurementLines(ctx).map(l => `${l.id}:${l.name}:${l.color}:${l.a.join(',')}:${l.b.join(',')}`).join('|');

  const Sources = {
    // One row per sample along each measurement line, in the frame on screen: the trilinear
    // value of every channel between the two picked points. The box around the lines is read
    // lossless at the finest level that holds it, so a short line is sampled on native voxels.
    line: {
      id: 'line',
      applies: (ctx, meta) => meta.type !== '2d' && Boolean(ctx.data) && measurementLines(ctx).length > 0,
      schema(ctx, t) {
        const meta = ctx.dataset.getMeta();
        const C = Math.max(1, meta.dimensions?.c || meta.channels?.length || 1);
        const lines = measurementLines(ctx);
        const vars = [
          { id: 'd', label: t('var_d'), unit: 'µm', kind: 'num' },
          { id: 'dr', label: t('var_dr'), unit: '', kind: 'num', dom: [0, 100], bins: 50, rel: true },
          { id: 'line', label: t('var_line'), unit: '', kind: 'cat', cats: { names: lines.map(l => l.name), colors: lines.map(l => l.color) } },
          ...channelVars(meta, t, C)
        ];
        return {
          id: 'line', label: t('table_line'), vars, measureUnit: '',
          defaults: { x: 'd', y: [INT], agg: 'mean', group: 'line' },
          presets: [
            { id: 'lineProfile', spec: { x: 'd', y: [INT], agg: 'mean', group: 'line' } },
            { id: 'lineProfileRel', spec: { x: 'dr', y: [INT], agg: 'mean', group: 'line' } }
          ]
        };
      },
      key(ctx) {
        const id = ctx.dataset.getId();
        let shown = null;
        try { shown = ctx.data && typeof ctx.data.displayedTree === 'function' ? ctx.data.displayedTree() : null; } catch (_) { shown = null; }
        return shown && shown.path ? `${id}|${String(shown.path).replace(/\/$/, '')}|${lineSignature(ctx)}` : null;
      },
      async build(ctx, schema, opts) {
        const D = ctx.data;
        const lines = measurementLines(ctx);
        if (!lines.length) throw gerr('NO_DATA', 'no measurement to sample');
        let info;
        try { info = D.info(); } catch (err) { throw gerr('NOT_READY', 'no volume mounted'); }
        const C = info.channels;
        const levels = D.levels();
        const AX = ['x', 'y', 'z'];
        const lo = [Infinity, Infinity, Infinity], hi = [-Infinity, -Infinity, -Infinity];
        let maxLen = 0;
        for (const l of lines) {
          for (const q of [l.a, l.b]) for (let k = 0; k < 3; k++) { lo[k] = Math.min(lo[k], q[k]); hi[k] = Math.max(hi[k], q[k]); }
          l.len = Math.hypot(l.b[0] - l.a[0], l.b[1] - l.a[1], l.b[2] - l.a[2]);
          maxLen = Math.max(maxLen, l.len);
        }
        // The box of the lines at a level, one voxel of margin for the trilinear taps, clamped to the volume.
        const boxAt = (L) => {
          const b = {};
          let n = 1;
          AX.forEach((a, k) => {
            const v = L.voxelSize[a], dim = L.dims[a];
            const v0 = clamp(Math.floor(lo[k] / v) - 1, 0, dim - 1);
            const v1 = clamp(Math.ceil(hi[k] / v) + 2, v0 + 1, dim);
            b[a + '0'] = v0; b[a + '1'] = v1;
            n *= v1 - v0;
          });
          return { b, n };
        };
        let pick = levels[levels.length - 1];
        let box = null;
        for (const L of levels) {
          const c = boxAt(L);
          if (c.n * C <= CHANNEL_BUDGET) { pick = L; box = c.b; break; }
        }
        if (!box) box = boxAt(pick).b;
        let reg;
        try {
          reg = await D.readRegion(box, Array.from({ length: C }, (_, i) => i), { level: pick.level, signal: opts && opts.signal, onProgress: opts && opts.onProgress });
        } catch (err) {
          if (err && err.name === 'AbortError') throw err;
          throw gerr(err && (err.code === 'NO_DATASET' || err.code === 'BRICKS_NOT_INITIALIZED') ? 'NOT_READY' : 'READ_FAILED', 'volume read failed');
        }
        const vs = pick.voxelSize;
        const w = reg.dims.x, h = reg.dims.y, dd = reg.dims.z;
        // Sampling step: the smallest voxel, coarser only to keep a line at ≤ MAX_BINS samples.
        const stepUm = Math.max(Math.min(vs.x, vs.y, vs.z), maxLen / (MAX_BINS - 1), 1e-9);
        const counts = lines.map(l => Math.floor(l.len / stepUm) + 1);
        const n = counts.reduce((a, b) => a + b, 0);
        const d = new Float32Array(n), dr = new Float32Array(n), lineIdx = new Uint8Array(n);
        const chVars = schema.vars.filter(v => v.ch);
        const cols = { d, dr, line: lineIdx };
        chVars.forEach(v => { cols[v.id] = new Float32Array(n); });
        const at = (c, x, y, z) => reg.data[c][(z * h + y) * w + x];
        let r = 0;
        lines.forEach((l, li) => {
          for (let i = 0; i < counts[li]; i++, r++) {
            const dist = i * stepUm;
            const f = l.len > 0 ? dist / l.len : 0;
            d[r] = dist; dr[r] = l.len > 0 ? f * 100 : 0; lineIdx[r] = li;
            // Voxel centres sit at (i + 0.5) · size from the corner of voxel 0.
            const ux = clamp(((l.a[0] + f * (l.b[0] - l.a[0])) / vs.x) - 0.5 - box.x0, 0, w - 1);
            const uy = clamp(((l.a[1] + f * (l.b[1] - l.a[1])) / vs.y) - 0.5 - box.y0, 0, h - 1);
            const uz = clamp(((l.a[2] + f * (l.b[2] - l.a[2])) / vs.z) - 0.5 - box.z0, 0, dd - 1);
            const x0 = Math.floor(ux), y0 = Math.floor(uy), z0 = Math.floor(uz);
            const x1 = Math.min(w - 1, x0 + 1), y1 = Math.min(h - 1, y0 + 1), z1 = Math.min(dd - 1, z0 + 1);
            const tx = ux - x0, ty = uy - y0, tz = uz - z0;
            chVars.forEach(v => {
              const c = v.channelIndex;
              const c00 = at(c, x0, y0, z0) * (1 - tx) + at(c, x1, y0, z0) * tx;
              const c10 = at(c, x0, y1, z0) * (1 - tx) + at(c, x1, y1, z0) * tx;
              const c01 = at(c, x0, y0, z1) * (1 - tx) + at(c, x1, y0, z1) * tx;
              const c11 = at(c, x0, y1, z1) * (1 - tx) + at(c, x1, y1, z1) * tx;
              cols[v.id][r] = (c00 * (1 - ty) + c10 * ty) * (1 - tz) + (c01 * (1 - ty) + c11 * ty) * tz;
            });
          }
        });
        const vars = schema.vars.map(v => ({ ...v }));
        vars.forEach(v => {
          if (v.id === 'd') { v.step = stepUm; v.dom = [0, (Math.max(...counts) - 1) * stepUm]; }
          if (v.id === 'line') v.cats = { names: lines.map(l => l.name), colors: lines.map(l => l.color) };
        });
        return {
          id: 'line', n, cols, vars, defaults: schema.defaults, measureUnit: '', unitSize: 1,
          info: { level: pick.level, dims: reg.dims, voxelSize: vs, lines: lines.length, step: stepUm }
        };
      }
    },

    voxels: {
      id: 'voxels',
      applies: (ctx, meta) => meta.type !== '2d' && Boolean(ctx.data),
      schema(ctx, t) {
        const meta = ctx.dataset.getMeta();
        const C = Math.max(1, meta.dimensions?.c || meta.channels?.length || 1);
        const vars = [...positionVars(t, 'µm'), ...channelVars(meta, t, C)];
        const ints = vars.filter(v => v.ch).map(v => v.id);
        return {
          id: 'voxels', label: t('table_voxels'), vars, measureUnit: 'µm³',
          defaults: { x: 'zr', y: [INT], agg: 'mean' },
          presets: [
            { id: 'zProfile', spec: { x: 'zr', y: [INT], agg: 'mean', bins: 50 } },
            { id: 'zSignal', spec: { x: 'zr', y: [INT], agg: 'measure', bins: 50 } },
            { id: 'xProfile', spec: { x: 'xr', y: [INT], agg: 'mean', bins: 50 } },
            { id: 'yProfile', spec: { x: 'yr', y: [INT], agg: 'mean', bins: 50 } },
            { id: 'hist', spec: { x: INT, agg: 'count', yScale: 'log' } },
            { id: 'summaryMean', spec: { x: ALL, y: [INT], agg: 'mean', band: true } },
            { id: 'summarySignal', spec: { x: ALL, y: [INT], agg: 'measure' } },
            ints.length > 1 ? { id: 'coloc', spec: { x: '@int[0]', y: ['@int[1]'], agg: 'density', yScale: 'log' } } : null
          ].filter(Boolean)
        };
      },
      // The tree the read will use: the frame on screen (ctx.data pins it), not the tree
      // BrickLoader has mounted, which the timelapse prefetch moves to later frames and a
      // cached frame shown leaves behind. A prefetch mount then rebuilds nothing, and a scrub
      // to a cached frame rebuilds the table. Null while ctx.data names no tree on screen
      // (the volumes released by a WebGL context loss, nothing activated yet): the mounted
      // tree is then a prefetched frame, so nothing is marked stale and nothing is read.
      // Only a host whose ctx.data cannot say at all keys on the mounted tree.
      key(ctx) {
        const id = ctx.dataset.getId();
        if (ctx.data && typeof ctx.data.displayedTree === 'function') {
          let shown = null;
          try { shown = ctx.data.displayedTree(); } catch (_) { shown = null; }
          return shown && shown.path ? `${id}|${String(shown.path).replace(/\/$/, '')}` : null;
        }
        const base = typeof BrickLoader !== 'undefined' && BrickLoader.getBasePath ? (BrickLoader.getBasePath() || '') : '';
        return `${id}|${String(base).replace(/\/$/, '')}`;
      },
      async build(ctx, schema, opts) {
        const D = ctx.data;
        let info;
        try { info = D.info(); } catch (err) { throw gerr('NOT_READY', 'no volume mounted'); }
        const C = info.channels;
        const levels = D.levels();
        let pick = levels[levels.length - 1];
        for (const L of levels) {
          const n = L.dims.x * L.dims.y * L.dims.z;
          if (n <= ROW_BUDGET && n * C <= CHANNEL_BUDGET) { pick = L; break; }
        }
        const { x: dx, y: dy, z: dz } = pick.dims;
        const vs = pick.voxelSize;
        let reg;
        try {
          reg = await D.readRegion({ x0: 0, x1: dx, y0: 0, y1: dy, z0: 0, z1: dz }, Array.from({ length: C }, (_, i) => i), { level: pick.level, signal: opts && opts.signal, onProgress: opts && opts.onProgress });
        } catch (err) {
          if (err && err.name === 'AbortError') throw err;
          throw gerr(err && err.code === 'NO_DATASET' ? 'NOT_READY' : 'READ_FAILED', 'volume read failed');
        }
        const n = dx * dy * dz;
        const vars = schema.vars.map(v => ({ ...v }));
        const cols = {};
        vars.forEach(v => { if (v.ch) cols[v.id] = reg.data[v.channelIndex]; });
        const dimOf = [dx, dy, dz];
        const sizeOf = [vs.x, vs.y, vs.z];
        const lazy = {};
        vars.forEach(v => {
          if (!v.pos) return;
          const k = v.axis;
          if (v.rel) lazy[v.id] = { fill: 'axis', dims: dimOf, axis: k, scale: 100 / dimOf[k] };
          else {
            lazy[v.id] = { fill: 'axis', dims: dimOf, axis: k, scale: sizeOf[k] };
            v.dom = [0.5 * sizeOf[k], (dimOf[k] - 0.5) * sizeOf[k]];
            if (dimOf[k] <= MAX_BINS) v.step = sizeOf[k];
          }
          if (v.rel && dimOf[k] <= MAX_BINS) v.step = 100 / dimOf[k];
          if (v.rel) v.dom = [50 / dimOf[k], 100 - 50 / dimOf[k]];
        });
        // `owned`: the columns are this table's alone (a fresh read), so they can be
        // handed to the engine worker instead of copied.
        return {
          id: 'voxels', n, cols, lazy, vars, defaults: schema.defaults, measureUnit: 'µm³', unitSize: vs.x * vs.y * vs.z,
          info: { level: pick.level, dims: pick.dims, voxelSize: vs }, owned: true
        };
      }
    },

    pixels: {
      id: 'pixels',
      applies: (ctx, meta) => meta.type === '2d' && Boolean(meta.image?.native) && Boolean(ctx.dataset?.fileUrl),
      schema(ctx, t) {
        const meta = ctx.dataset.getMeta();
        const cal = Number(meta?.pixelSizeUm?.x) > 0;
        const unit = cal ? 'µm' : 'px';
        const ch = (id, label, color) => ({ id, label, unit: '', kind: 'num', dom: [0, 255], step: 1, bins: 64, intensity: true, ch: true, color });
        const vars = [
          { id: 'x', label: t('var_x'), unit, kind: 'num', pos: true, axis: 0 },
          { id: 'y', label: t('var_y'), unit, kind: 'num', pos: true, axis: 1 },
          { id: 'xr', label: t('var_xr'), unit: '', kind: 'num', dom: [0, 100], bins: 50, pos: true, axis: 0, rel: true },
          { id: 'yr', label: t('var_yr'), unit: '', kind: 'num', dom: [0, 100], bins: 50, pos: true, axis: 1, rel: true },
          ch('R', t('var_R'), '#e34948'), ch('G', t('var_G'), '#008300'), ch('B', t('var_B'), '#2a78d6'),
          { id: 'L', label: t('var_L'), unit: '', kind: 'num', dom: [0, 255], step: 1, bins: 64, intensity: true, color: null },
          { id: 'S', label: t('var_S'), unit: '%', kind: 'num', dom: [0, 100], bins: 50, color: null },
          { id: 'blue', label: t('var_blue'), unit: '', kind: 'num', dom: [-255, 255], bins: 64, color: null }
        ];
        return {
          id: 'pixels', label: t('table_pixels'), vars, measureUnit: cal ? 'µm²' : 'px²',
          defaults: { x: 'xr', y: [INT], agg: 'mean' },
          presets: [
            { id: 'rgbHist', spec: { x: INT, agg: 'count' } },
            { id: 'lumHist', spec: { x: 'L', agg: 'count' } },
            { id: 'blueHist', spec: { x: 'blue', agg: 'count', yScale: 'log' } },
            { id: 'xColour', spec: { x: 'xr', y: [INT], agg: 'mean', bins: 50 } },
            { id: 'yColour', spec: { x: 'yr', y: [INT], agg: 'mean', bins: 50 } },
            { id: 'summaryMean', spec: { x: ALL, y: [INT], agg: 'mean', band: true } },
            { id: 'colocRB', spec: { x: 'R', y: ['B'], agg: 'density', yScale: 'log' } }
          ]
        };
      },
      key(ctx) { return ctx.dataset.getId(); },
      async build(ctx, schema, opts) {
        // The photograph's own file, not what the viewer draws: display adjustments,
        // stain isolation and rotation must not change a measurement.
        const meta0 = ctx.dataset.getMeta();
        let bitmap;
        try {
          const resp = await fetch(ctx.dataset.fileUrl({ path: ctx.dataset.getId() }, meta0.image.native), { signal: opts && opts.signal });
          if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
          bitmap = await createImageBitmap(await resp.blob());
        } catch (err) {
          if (err && err.name === 'AbortError') throw err;
          console.error('[graphs] photograph unreadable:', err);
          throw gerr('READ_FAILED', 'photograph unreadable');
        }
        const W = bitmap.width, H = bitmap.height;
        const s = Math.min(1, Math.sqrt(PIXEL_BUDGET / (W * H)));
        const w = Math.max(1, Math.round(W * s)), h = Math.max(1, Math.round(H * s));
        const cv = document.createElement('canvas');
        cv.width = w; cv.height = h;
        const g = cv.getContext('2d', { willReadFrequently: true });
        g.imageSmoothingEnabled = true;
        g.drawImage(bitmap, 0, 0, w, h);
        if (bitmap.close) bitmap.close();
        const px = g.getImageData(0, 0, w, h).data;
        const n = w * h;
        const R = new Uint8Array(n), G = new Uint8Array(n), B = new Uint8Array(n), L = new Uint8Array(n), S = new Uint8Array(n);
        const blue = new Int16Array(n);
        for (let i = 0, p = 0; i < n; i++, p += 4) {
          const r = px[p], gg = px[p + 1], b = px[p + 2];
          R[i] = r; G[i] = gg; B[i] = b;
          L[i] = Math.round(0.2126 * r + 0.7152 * gg + 0.0722 * b);      // Rec. 709 luma
          const mx = Math.max(r, gg, b), mn = Math.min(r, gg, b);
          S[i] = mx ? Math.round(((mx - mn) / mx) * 100) : 0;
          blue[i] = b - r;                                              // X-gal reads blue: B − R is the stain's excess over the tissue's yellow
        }
        const meta = ctx.dataset.getMeta();
        const px0 = Number(meta?.pixelSizeUm?.x) > 0 ? Number(meta.pixelSizeUm.x) : 1;
        const py0 = Number(meta?.pixelSizeUm?.y) > 0 ? Number(meta.pixelSizeUm.y) : px0;
        const sx = (W / w) * px0, sy = (H / h) * py0;
        const vars = schema.vars.map(v => ({ ...v }));
        const lazy = {};
        vars.forEach(v => {
          if (!v.pos) return;
          const dim = v.axis === 0 ? w : h, size = v.axis === 0 ? sx : sy;
          if (v.rel) { lazy[v.id] = { fill: 'axis', dims: [w, h], axis: v.axis, scale: 100 / dim }; v.dom = [50 / dim, 100 - 50 / dim]; }
          else { lazy[v.id] = { fill: 'axis', dims: [w, h], axis: v.axis, scale: size }; v.dom = [0.5 * size, (dim - 0.5) * size]; }
        });
        return {
          id: 'pixels', n, cols: { R, G, B, L, S, blue }, lazy, vars, defaults: schema.defaults, measureUnit: schema.measureUnit, unitSize: sx * sy,
          info: { dims: { x: w, y: h }, scale: s }, owned: true
        };
      }
    },

    frames: {
      id: 'frames',
      applies: (ctx, meta) => meta.type === 'live' && Boolean(meta.intensityNormalization?.signalLevels),
      schema(ctx, t) {
        const meta = ctx.dataset.getMeta();
        const { unit } = dtOf(meta);
        const C = Math.max(1, meta.dimensions?.c || meta.channels?.length || 1);
        const chans = channelVars(meta, t, C, { prefix: '' });
        const vars = [{ id: 't', label: t('var_t'), unit, kind: 'num', step: 0, time: true },
          { id: 'tr', label: t('var_tr'), unit: '', kind: 'num', dom: [0, 100], bins: 50, rel: true }];
        chans.forEach(c => {
          vars.push({ id: 'sig_' + c.id, label: t('var_signal', { ch: c.label }), unit: '', kind: 'num', color: c.color, ci: c.channelIndex });
          vars.push({ id: 'rel_' + c.id, label: t('var_signalRel', { ch: c.label }), unit: '%', kind: 'num', color: c.color, ci: c.channelIndex, rel0: true });
        });
        return {
          id: 'frames', label: t('table_frames'), vars, measureUnit: '',
          defaults: { x: 't', y: [(vars.find(v => v.rel0) || vars.find(v => v.ci !== undefined) || vars[0]).id], agg: 'mean' },
          presets: [
            { id: 'bleach', spec: { x: 't', y: vars.filter(v => v.rel0).map(v => v.id), agg: 'mean' } },
            { id: 'signalTime', spec: { x: 't', y: vars.filter(v => v.id.startsWith('sig_')).map(v => v.id), agg: 'mean' } }
          ]
        };
      },
      key(ctx) { return ctx.dataset.getId(); },
      async build(ctx, schema) {
        const meta = ctx.dataset.getMeta();
        const { dt } = dtOf(meta);
        const levels = meta.intensityNormalization.signalLevels || {};
        const T = Math.max(1, Number(meta.dimensions?.t) || 1);
        const vars = schema.vars.map(v => ({ ...v }));
        const cols = { t: new Float32Array(T) };
        for (let f = 0; f < T; f++) cols.t[f] = f * dt;
        cols.tr = new Float32Array(T);
        for (let f = 0; f < T; f++) cols.tr[f] = T > 1 ? (f / (T - 1)) * 100 : 0;
        vars.forEach(v => {
          if (v.ci === undefined) return;
          const a = new Float32Array(T).fill(NaN);
          for (let f = 0; f < T; f++) {
            const val = levels[`t${String(f).padStart(3, '0')}_c${v.ci}`];
            if (Number.isFinite(val)) a[f] = val;
          }
          if (v.rel0) {
            const base = a.find(x => Number.isFinite(x) && x > 0);
            for (let f = 0; f < T; f++) a[f] = base ? (a[f] / base) * 100 : NaN;
          }
          cols[v.id] = a;
        });
        vars[0].step = dt;
        vars[0].dom = [0, (T - 1) * dt];
        return { id: 'frames', n: T, cols, vars, defaults: schema.defaults, measureUnit: '', unitSize: 1 };
      }
    }
  };

  // — Cell tracking: three tables from the same pass over the packed tracks —

  const trackingMemo = { key: null, value: null };

  function trackingKey(ctx) {
    const T = ctx.tracking;
    const data = T.getData();
    return { data, stab: T.isStabilized(), id: ctx.dataset.getId() };
  }

  function buildTracking(ctx, t) {
    const T = ctx.tracking;
    const k = trackingKey(ctx);
    const memo = trackingMemo.key;
    if (memo && memo.data === k.data && memo.stab === k.stab && memo.id === k.id && trackingMemo.t === t) return trackingMemo.value;
    const data = k.data;
    if (!data) throw gerr('NOT_READY', 'tracking not loaded');
    const meta = ctx.dataset.getMeta();
    const { dt, unit } = dtOf(meta);
    const F = data.frameCount;
    let rowsMax = 0;
    for (let c = 0; c < data.cellTotal; c++) if (data.firstFrame[c] >= 0) rowsMax += Math.max(0, data.lastFrame[c] - data.firstFrame[c] + 1);
    const cell = new Uint32Array(rowsMax), frame = new Uint16Array(rowsMax);
    const tt = new Float32Array(rowsMax), X = new Float32Array(rowsMax), Y = new Float32Array(rowsMax), Z = new Float32Array(rowsMax);
    const speed = new Float32Array(rowsMax).fill(NaN), age = new Float32Array(rowsMax), disp = new Float32Array(rowsMax), pathCum = new Float32Array(rowsMax);
    const reg = new Int16Array(rowsMax);
    const NC = data.cellTotal;
    const rowStart = new Uint32Array(NC + 1);
    const c_first = new Float32Array(NC).fill(NaN), c_last = new Float32Array(NC).fill(NaN), c_life = new Float32Array(NC).fill(NaN);
    const c_path = new Float32Array(NC).fill(NaN), c_disp = new Float32Array(NC).fill(NaN), c_str = new Float32Array(NC).fill(NaN);
    const c_mean = new Float32Array(NC).fill(NaN), c_max = new Float32Array(NC).fill(NaN);
    const c_x = new Float32Array(NC).fill(NaN), c_y = new Float32Array(NC).fill(NaN), c_z = new Float32Array(NC).fill(NaN);
    const c_reg = new Int16Array(NC), c_mit = new Uint8Array(NC), c_fus = new Uint8Array(NC), c_dau = new Uint16Array(NC), c_div = new Float32Array(NC).fill(NaN);

    const um = [0, 0, 0];
    let r = 0;
    for (let c = 0; c < NC; c++) {
      rowStart[c] = r;
      c_reg[c] = data.regionIdx[c];
      c_mit[c] = data.flags[c] & 1 ? 1 : 0;
      c_fus[c] = data.flags[c] & 2 ? 1 : 0;
      c_dau[c] = data.daughterStart[c + 1] - data.daughterStart[c];
      if (data.firstFrame[c] < 0) continue;
      let prevF = -2, px = 0, py = 0, pz = 0, ox = 0, oy = 0, oz = 0, path = 0, pathCons = 0, steps = 0, vmax = 0, sx = 0, sy = 0, sz = 0, cnt = 0, firstRow = -1, lastRow = -1;
      for (let f = data.firstFrame[c]; f <= data.lastFrame[c]; f++) {
        if (!T.positionUm(c, f, {}, um)) { prevF = -2; continue; }
        const x = um[0], y = um[1], z = um[2];
        cell[r] = c; frame[r] = f; tt[r] = f * dt; X[r] = x; Y[r] = y; Z[r] = z; reg[r] = data.regionIdx[c];
        age[r] = (f - data.firstFrame[c]) * dt;
        if (cnt === 0) { ox = x; oy = y; oz = z; firstRow = r; }
        if (cnt > 0) {
          // The path counts the straight jump over a gap too (so net / path stays ≤ 1);
          // speed only comes from steps between consecutive frames.
          const d = Math.hypot(x - px, y - py, z - pz);
          path += d;
          if (prevF === f - 1) {
            const v = d / dt;
            speed[r] = v; pathCons += d; steps++;
            if (v > vmax) vmax = v;
          }
        }
        pathCum[r] = path;
        disp[r] = Math.hypot(x - ox, y - oy, z - oz);
        px = x; py = y; pz = z; prevF = f; sx += x; sy += y; sz += z; cnt++; lastRow = r;
        r++;
      }
      if (cnt) {
        c_first[c] = data.firstFrame[c] * dt; c_last[c] = data.lastFrame[c] * dt;
        c_life[c] = (data.lastFrame[c] - data.firstFrame[c] + 1) * dt;
        c_path[c] = path; c_disp[c] = disp[lastRow];
        c_str[c] = path > 0 ? disp[lastRow] / path : NaN;
        c_mean[c] = steps ? pathCons / (steps * dt) : NaN;
        c_max[c] = steps ? vmax : NaN;
        c_x[c] = sx / cnt; c_y[c] = sy / cnt; c_z[c] = sz / cnt;
      }
      if (c_mit[c]) {
        let when = -1;
        for (let q = data.daughterStart[c]; q < data.daughterStart[c + 1]; q++) {
          const d = data.daughterIdx[q];
          if (data.firstFrame[d] >= 0 && (when < 0 || data.firstFrame[d] < when)) when = data.firstFrame[d];
        }
        if (when < 0) when = data.lastFrame[c];
        if (when >= 0) c_div[c] = when * dt;
      }
      void firstRow;
    }
    rowStart[NC] = r;
    const N = r;
    const trim = (a) => a.subarray(0, N);
    // Time as a share of the acquisition: datasets with different frame counts or intervals line up.
    const trel = new Float32Array(N);
    for (let i = 0; i < N; i++) trel[i] = F > 1 ? (frame[i] / (F - 1)) * 100 : 0;
    const c_divr = new Float32Array(NC).fill(NaN);
    for (let c = 0; c < NC; c++) if (Number.isFinite(c_div[c]) && F > 1) c_divr[c] = (c_div[c] / ((F - 1) * dt)) * 100;
    const cats = {
      region: { names: Array.from(data.regionNames), colors: Array.from(data.regionColors) },
      yesno: { names: [t('no'), t('yes')], colors: null }
    };
    const value = {
      N, NC, F, dt, unit, data, cats, rowStart,
      obs: {
        cols: { t: trim(tt), tr: trel, frame: trim(frame), x: trim(X), y: trim(Y), z: trim(Z), speed: trim(speed), age: trim(age), disp: trim(disp), path: trim(pathCum), region: trim(reg), cell: trim(cell) }
      },
      cells: {
        cols: { firstT: c_first, lastT: c_last, lifetime: c_life, path: c_path, disp: c_disp, straight: c_str, meanSpeed: c_mean, maxSpeed: c_max, divTr: c_divr, x: c_x, y: c_y, z: c_z, region: c_reg, mitosis: c_mit, fusion: c_fus, daughters: c_dau, divT: c_div }
      }
    };
    trackingMemo.key = k; trackingMemo.t = t; trackingMemo.value = value;
    return value;
  }

  /** Cells within the inspector radius, per observation, in its own frame. The grid has
   *  edge `radius`, so every neighbour lies in the 27 buckets around a cell; a bucket key is
   *  an exact integer of the bucket's coordinates (a hash that collides would count the
   *  same neighbours twice). */
  function neighbourColumn(ctx, tr) {
    const radius = ctx.tracking.getOptions().neighborThresholdUm;
    const r2 = radius * radius, size = Math.max(radius, 1e-6);
    const { N, F } = tr;
    const { frame, x, y, z } = tr.obs.cols;
    const out = new Float32Array(N).fill(NaN);
    const start = new Uint32Array(F + 1);
    for (let i = 0; i < N; i++) start[frame[i] + 1]++;
    for (let f = 0; f < F; f++) start[f + 1] += start[f];
    const order = new Uint32Array(N);
    const fill = start.slice(0, F);
    for (let i = 0; i < N; i++) order[fill[frame[i]]++] = i;
    const next = new Int32Array(N);
    const head = new Map();
    const cx = new Int32Array(N), cy = new Int32Array(N), cz = new Int32Array(N);
    for (let f = 0; f < F; f++) {
      const s0 = start[f], s1 = start[f + 1];
      if (s1 === s0) continue;
      let ax = Infinity, bx = -Infinity, ay = Infinity, by = -Infinity, az = Infinity, bz = -Infinity;
      for (let q = s0; q < s1; q++) {
        const i = order[q];
        const a = Math.floor(x[i] / size), b = Math.floor(y[i] / size), c = Math.floor(z[i] / size);
        cx[i] = a; cy[i] = b; cz[i] = c;
        if (a < ax) ax = a; if (a > bx) bx = a;
        if (b < ay) ay = b; if (b > by) by = b;
        if (c < az) az = c; if (c > bz) bz = c;
      }
      // Spans padded by one on each side: a neighbour bucket outside the data still has a key.
      const ny = by - ay + 3, nz = bz - az + 3;
      const exact = (bx - ax + 3) * ny * nz < 2 ** 52;
      const keyOf = exact
        ? (a, b, c) => ((a - ax + 1) * ny + (b - ay + 1)) * nz + (c - az + 1)
        : (a, b, c) => `${a},${b},${c}`;
      head.clear();
      for (let q = s0; q < s1; q++) {
        const i = order[q];
        const k = keyOf(cx[i], cy[i], cz[i]);
        const h = head.get(k);
        next[i] = h === undefined ? -1 : h;
        head.set(k, i);
      }
      for (let q = s0; q < s1; q++) {
        const i = order[q];
        let count = 0;
        for (let a = cx[i] - 1; a <= cx[i] + 1; a++) for (let b = cy[i] - 1; b <= cy[i] + 1; b++) for (let c = cz[i] - 1; c <= cz[i] + 1; c++) {
          const h = head.get(keyOf(a, b, c));
          if (h === undefined) continue;
          for (let j = h; j >= 0; j = next[j]) {
            if (j === i) continue;
            const dx = x[i] - x[j], dy = y[i] - y[j], dz = z[i] - z[j];
            if (dx * dx + dy * dy + dz * dz <= r2) count++;
          }
        }
        out[i] = count;
      }
    }
    return out;
  }

  /** Time-averaged mean squared displacement of every cell for every lag it covers. */
  function msdRows(tr) {
    const { NC, F, dt, rowStart } = tr;
    const { frame, x, y, z, region } = tr.obs.cols;
    let maxLag = Math.max(1, Math.min(F - 1, Math.floor(F / 2)));
    const OPS = 6e7;
    let ops = 0;
    for (let c = 0; c < NC; c++) ops += (rowStart[c + 1] - rowStart[c]) * maxLag;
    // Past the budget the sum runs over a regular sample of the cells, not over fewer lags:
    // the long lags are where diffusive and directed motion part.
    const cellStride = ops > OPS ? Math.ceil(ops / OPS) : 1;
    const cap = Math.ceil(NC / cellStride) * maxLag;
    const lag = new Float32Array(cap), msd = new Float32Array(cap), reg = new Int16Array(cap), cl = new Uint32Array(cap);
    let n = 0;
    for (let c = 0; c < NC; c += cellStride) {
      const a = rowStart[c], b = rowStart[c + 1];
      if (b - a < 2) continue;
      const f0 = frame[a], len = frame[b - 1] - f0 + 1;
      const dense = new Int32Array(len).fill(-1);
      for (let i = a; i < b; i++) dense[frame[i] - f0] = i;
      for (let L = 1; L <= maxLag && L < len; L++) {
        let sum = 0, cnt = 0;
        for (let k = 0; k + L < len; k++) {
          const i = dense[k], j = dense[k + L];
          if (i < 0 || j < 0) continue;
          const dx = x[j] - x[i], dy = y[j] - y[i], dz = z[j] - z[i];
          sum += dx * dx + dy * dy + dz * dz; cnt++;
        }
        if (!cnt) continue;
        lag[n] = L * dt; msd[n] = sum / cnt; reg[n] = region[a]; cl[n] = c; n++;
      }
    }
    return { n, sampled: cellStride > 1, lag: lag.subarray(0, n), msd: msd.subarray(0, n), region: reg.subarray(0, n), cell: cl.subarray(0, n) };
  }

  function trackingSchemas(ctx, t) {
    const meta = ctx.dataset.getMeta();
    const { unit } = dtOf(meta);
    const speedUnit = `µm/${unit}`;
    const regionNames = (meta.tracking?.regions || []).map(r => r.name);
    const regionCats = { names: regionNames, colors: (meta.tracking?.regions || []).map(r => safeColor(r && r.color)) };
    const yesno = { names: [t('no'), t('yes')], colors: null };
    const pos = (id, label) => ({ id, label, unit: 'µm', kind: 'num' });
    const num = (id, label, u, extra) => ({ id, label, unit: u || '', kind: 'num', ...extra });
    const cat = (id, label, cats) => ({ id, label, unit: '', kind: 'cat', cats });
    const tvar = { id: 't', label: t('var_t'), unit, kind: 'num', step: dtOf(meta).dt, time: true };
    const relvar = (id, label) => ({ id, label, unit: '', kind: 'num', dom: [0, 100], bins: 50, rel: true });
    return [
      {
        id: 'obs', label: t('table_obs'), measureUnit: '',
        vars: [tvar, relvar('tr', t('var_tr')), num('age', t('var_age'), unit), pos('x', t('var_x')), pos('y', t('var_y')), pos('z', t('var_z')),
          num('speed', t('var_speed'), speedUnit), num('disp', t('var_disp'), 'µm'), num('path', t('var_path'), 'µm'),
          num('neighbors', t('var_neighbors'), '', { lazyCost: true }), cat('region', t('var_region'), regionCats)],
        defaults: { x: 't', y: ['speed'], agg: 'mean', group: 'region' },
        presets: [
          { id: 'population', spec: { x: 't', agg: 'count', group: 'region' } },
          { id: 'speedTime', spec: { x: 't', y: ['speed'], agg: 'mean', group: 'region' } },
          { id: 'speedHist', spec: { x: 'speed', agg: 'count', group: 'region', normalize: 'sum' } },
          { id: 'neighborsTime', spec: { x: 't', y: ['neighbors'], agg: 'mean', group: 'region' } },
          { id: 'dispAge', spec: { x: 'age', y: ['disp'], agg: 'mean', group: 'region', band: true } },
          { id: 'speedDepth', spec: { x: 'z', y: ['speed'], agg: 'mean', band: true } },
          { id: 'xyPlane', spec: { x: 'x', y: ['y'], agg: 'points', group: 'region' } }
        ]
      },
      {
        id: 'cells', label: t('table_cells'), measureUnit: '',
        vars: [num('lifetime', t('var_lifetime'), unit), num('firstT', t('var_firstT'), unit), num('lastT', t('var_lastT'), unit),
          num('path', t('var_path'), 'µm'), num('disp', t('var_dispEnd'), 'µm'), num('straight', t('var_straight'), ''),
          num('meanSpeed', t('var_meanSpeed'), speedUnit), num('maxSpeed', t('var_maxSpeed'), speedUnit),
          pos('x', t('var_cx')), pos('y', t('var_cy')), pos('z', t('var_cz')),
          num('divT', t('var_divT'), unit, { step: dtOf(meta).dt }), relvar('divTr', t('var_divTr')), num('daughters', t('var_daughters'), ''),
          cat('region', t('var_region'), regionCats), cat('mitosis', t('var_mitosis'), yesno), cat('fusion', t('var_fusion'), yesno)],
        defaults: { x: 'region', y: ['meanSpeed'], agg: 'mean' },
        presets: [
          { id: 'cellsPerRegion', spec: { x: 'region', agg: 'count' } },
          { id: 'speedRegion', spec: { x: 'region', y: ['meanSpeed'], agg: 'mean', band: true } },
          { id: 'lifetimeHist', spec: { x: 'lifetime', agg: 'count', group: 'region' } },
          { id: 'divisions', spec: { x: 'divT', agg: 'count', group: 'region' } },
          { id: 'speedStraight', spec: { x: 'meanSpeed', y: ['straight'], agg: 'points', group: 'region' } },
          { id: 'mitosisSpeed', spec: { x: 'mitosis', y: ['meanSpeed'], agg: 'mean', band: true } }
        ]
      },
      {
        id: 'msd', label: t('table_msd'), measureUnit: '',
        vars: [num('lag', t('var_lag'), unit, { step: dtOf(meta).dt, time: true }), num('msd', t('var_msd'), 'µm²'), cat('region', t('var_region'), regionCats)],
        defaults: { x: 'lag', y: ['msd'], agg: 'mean', group: 'region' },
        presets: [
          { id: 'msdLag', spec: { x: 'lag', y: ['msd'], agg: 'mean', group: 'region' } },
          { id: 'msdLog', spec: { x: 'lag', y: ['msd'], agg: 'mean', group: 'region', xScale: 'log', yScale: 'log' } }
        ]
      }
    ];
  }

  const TrackingSources = {
    applies: (ctx, meta) => meta.type === 'live' && Boolean(ctx.tracking && ctx.tracking.isAvailable()),
    key(ctx, id) {
      const T = ctx.tracking;
      const extra = id === 'obs' ? `|${T.getOptions().neighborThresholdUm}` : '';
      return `${ctx.dataset.getId()}|${T.isStabilized()}|${T.isLoaded()}${extra}`;
    },
    async build(ctx, schema, t) {
      const T = ctx.tracking;
      if (T.whenLoaded) await T.whenLoaded();
      const tr = buildTracking(ctx, t);
      const vars = schema.vars.map(v => ({ ...v }));
      if (schema.id === 'obs') {
        const cols = { ...tr.obs.cols };
        const lazy = { neighbors: () => neighbourColumn(ctx, tr) };
        vars.forEach(v => {
          if (v.id === 'region') v.cats = tr.cats.region;
          if (v.id === 't') { v.dom = [0, (tr.F - 1) * tr.dt]; v.step = tr.dt; }
        });
        return { id: 'obs', n: tr.N, cols, lazy, vars, defaults: schema.defaults, measureUnit: '', unitSize: 1 };
      }
      if (schema.id === 'cells') {
        vars.forEach(v => {
          if (v.id === 'region') v.cats = tr.cats.region;
          if (v.id === 'mitosis' || v.id === 'fusion') v.cats = tr.cats.yesno;
          if (v.id === 'divT') v.dom = [0, (tr.F - 1) * tr.dt];
        });
        return { id: 'cells', n: tr.NC, cols: { ...tr.cells.cols }, vars, defaults: schema.defaults, measureUnit: '', unitSize: 1 };
      }
      const m = msdRows(tr);
      vars.forEach(v => { if (v.id === 'region') v.cats = tr.cats.region; if (v.id === 'lag') { let hi = tr.dt * 2; for (let i = 0; i < m.n; i++) if (m.lag[i] > hi) hi = m.lag[i]; v.dom = [tr.dt, hi]; } });
      return { id: 'msd', n: m.n, cols: { lag: m.lag, msd: m.msd, region: m.region }, vars, defaults: schema.defaults, measureUnit: '', unitSize: 1, notes: m.sampled ? ['msd-sampled'] : [] };
    }
  };

  /** Every table this page can offer, cheapest first, as schemas (no data read). */
  function allSchemas(ctx, t) {
    const meta = ctx.dataset.getMeta() || {};
    const out = [];
    const add = (source, src) => {
      const sc = source.schema(ctx, t);
      sc.source = src;
      out.push(sc);
    };
    if (Sources.voxels.applies(ctx, meta)) add(Sources.voxels, Sources.voxels);
    if (Sources.line.applies(ctx, meta)) add(Sources.line, Sources.line);
    if (Sources.pixels.applies(ctx, meta)) add(Sources.pixels, Sources.pixels);
    if (Sources.frames.applies(ctx, meta)) add(Sources.frames, Sources.frames);
    if (TrackingSources.applies(ctx, meta)) trackingSchemas(ctx, t).forEach(sc => { sc.source = TrackingSources; out.push(sc); });
    return out;
  }

  // ════════════════════════════════════════════════════════════════════
  // Latest wins — at most one query running per caller
  // ════════════════════════════════════════════════════════════════════

  function supersededError() {
    return Object.assign(new Error('superseded by a newer query'), { name: 'AbortError', code: 'SUPERSEDED' });
  }

  /** Wrap an async `run`: one call runs at a time; a call made while one runs waits,
   *  and a newer call replaces it (its promise rejects with SUPERSEDED). A slider
   *  drag then costs the query running now plus the last one, whatever its length.
   *  `cancel()` rejects the waiting call: a caller that drops its tables must call it
   *  first, or the waiting call starts right after the abort and builds them again. */
  function latestOnly(run) {
    let running = false;
    let pending = null;
    async function pump() {
      running = true;
      while (pending) {
        const job = pending;
        pending = null;
        try { job.resolve(await run(...job.args)); } catch (err) { job.reject(err); }
      }
      running = false;
    }
    const call = function (...args) {
      return new Promise((resolve, reject) => {
        if (pending) pending.reject(supersededError());
        pending = { args, resolve, reject };
        if (!running) pump();
      });
    };
    call.cancel = () => {
      const job = pending;
      pending = null;
      if (job) job.reject(supersededError());
    };
    return call;
  }

  // ════════════════════════════════════════════════════════════════════
  // Engine worker — the queries off the page's thread
  // ════════════════════════════════════════════════════════════════════
  //
  // A table is posted to the worker once per build (an owned table hands its columns
  // over, the others are copied); each query then posts only its spec. In Compare
  // every panel is a same-origin frame on the host's thread: a query computed there
  // would freeze every panel and the host at once.

  /** `url`: the worker script, or null for none. Every failure of the worker rejects
   *  with WORKER_FAILED and leaves the runner unavailable: the provider then computes
   *  on the page, which is where it computed before. */
  function createWorkerRunner(url) {
    let worker = null;
    let broken = !url || typeof Worker !== 'function';
    let failure = null;
    let nextId = 0;
    const waiting = new Map();

    function stop(err) {
      broken = true;
      failure = err;
      if (worker) { try { worker.terminate(); } catch (_) { /* already gone */ } }
      worker = null;
      for (const w of waiting.values()) w.reject(err);
      waiting.clear();
    }

    function ensure() {
      if (worker || broken) return worker;
      try { worker = new Worker(url); } catch (err) {
        console.error('[graphs] engine worker unavailable:', err);
        stop(gerr('WORKER_FAILED', 'worker did not start'));
        return null;
      }
      worker.onmessage = (e) => {
        const d = e.data;
        const w = d && waiting.get(d.id);
        if (!w) return;
        waiting.delete(d.id);
        if (d.ok) w.resolve(d.result);
        else w.reject(gerr(d.code || 'GRAPH_FAILED', String(d.code || 'GRAPH_FAILED')));
      };
      worker.onerror = (e) => {
        if (e && e.preventDefault) e.preventDefault();
        console.error('[graphs] engine worker failed:', e && (e.message || e));
        stop(gerr('WORKER_FAILED', 'worker failed'));
      };
      worker.onmessageerror = () => stop(gerr('WORKER_FAILED', 'unreadable worker message'));
      return worker;
    }

    function call(msg, transfer) {
      return new Promise((resolve, reject) => {
        const w = ensure();
        if (!w) { reject(failure || gerr('WORKER_FAILED', 'no worker')); return; }
        const id = ++nextId;
        waiting.set(id, { resolve, reject });
        try { w.postMessage({ ...msg, id }, transfer || []); } catch (err) {
          waiting.delete(id);
          reject(err);
        }
      });
    }

    return {
      get available() { return !broken; },
      load: (key, table, transfer) => call({ op: 'load', key, table }, transfer),
      column: (key, col, data) => call({ op: 'column', key, col, data }),
      compute: (key, spec) => call({ op: 'compute', key, spec }),
      drop(key) {
        if (!worker || broken) return;
        try { worker.postMessage({ op: 'drop', key }); } catch (_) { /* worker gone */ }
      },
      dispose() {
        stop(Object.assign(new Error('graphs closed'), { name: 'AbortError', code: 'DISPOSED' }));
      }
    };
  }

  /** The worker script beside this plugin's index.js. */
  function engineWorkerUrl() {
    try {
      const mod = typeof PluginRegistry !== 'undefined' && PluginRegistry.getModule ? PluginRegistry.getModule('graphs') : null;
      const base = mod && mod.meta && mod.meta._path;
      return base ? `${base}/engine-worker.js` : null;
    } catch (_) { return null; }
  }

  /** What crosses to the worker: data only (a lazy function stays here) and, for a
   *  table whose columns are its own, their buffers to hand over. */
  function wireTable(tb) {
    const cols = {};
    const buffers = new Set();
    for (const [id, c] of Object.entries(tb.cols || {})) {
      cols[id] = c;
      if (tb.owned && c && c.buffer) buffers.add(c.buffer);
    }
    const lazy = {};
    for (const [id, L] of Object.entries(tb.lazy || {})) if (L && typeof L === 'object') lazy[id] = L;
    return {
      table: { id: tb.id, n: tb.n, cols, lazy, vars: tb.vars, defaults: tb.defaults || null, measureUnit: tb.measureUnit || '', unitSize: tb.unitSize || 1, notes: tb.notes || [] },
      transfer: [...buffers]
    };
  }

  /** Variable ids a spec reads (tokens such as @int are channels, never lazy). */
  function specIds(spec) {
    const out = [];
    if (spec && typeof spec.x === 'string') out.push(spec.x);
    if (spec && Array.isArray(spec.y)) spec.y.forEach(id => { if (typeof id === 'string') out.push(id); });
    if (spec && typeof spec.group === 'string') out.push(spec.group);
    return out;
  }

  // ════════════════════════════════════════════════════════════════════
  // Data provider — tables of THIS page, cached, with the queries on them
  // ════════════════════════════════════════════════════════════════════

  /** The language the labels of a description are in (null when the page cannot say). */
  function languageOf(ctx) {
    try { return (ctx.i18n && typeof ctx.i18n.getLanguage === 'function' && ctx.i18n.getLanguage()) || null; } catch (_) { return null; }
  }

  /** `opts.runner`: an engine runner (createWorkerRunner) or null to compute here. */
  function createProvider(ctx, t, opts = {}) {
    const runner = opts.runner || null;
    // id -> { key, ctrl, promise, token, sent }: one table per id, for the state that
    // was on screen when it was asked for. `token` names its copy in the worker.
    const cache = new Map();
    // Per table, the key of the last build refused NOT_READY: once the state it waited for
    // is there (another key, not null), the table counts as stale so a follow redraws it.
    const notReady = new Map();
    let schemasMemo = null;
    let serial = 0;
    let memoSig = null;
    const schemaSig = () => { try { return lineSignature(ctx); } catch (_) { return ''; } };
    const schemas = () => {
      const sig = schemaSig();
      if (!schemasMemo || sig !== memoSig) { schemasMemo = allSchemas(ctx, t); memoSig = sig; }
      return schemasMemo;
    };

    function describe() {
      const meta = ctx.dataset.getMeta() || {};
      return {
        datasetId: ctx.dataset.getId(), name: meta.name || ctx.dataset.getId(), type: meta.type || null,
        lang: languageOf(ctx),
        tables: schemas().map(sc => ({
          id: sc.id, label: sc.label, measureUnit: sc.measureUnit || '', defaults: sc.defaults,
          presets: sc.presets || [],
          vars: sc.vars.map(v => ({ id: v.id, label: v.label, unit: v.unit || '', kind: v.kind, intensity: Boolean(v.intensity), ch: Boolean(v.ch), color: v.color || null, cats: v.cats || null, rel: Boolean(v.rel), time: Boolean(v.time), lazyCost: Boolean(v.lazyCost) }))
        })),
        cursor: cursorMinutes()
      };
    }

    function cursorMinutes() {
      const meta = ctx.dataset.getMeta() || {};
      if (meta.type !== 'live') return null;
      const { dt } = dtOf(meta);
      let f = null;
      try { f = ctx._state && ctx._state.currentTimepoint; } catch (_) { f = null; }
      return Number.isFinite(f) ? { value: f * dt, frame: f } : null;
    }

    function schemaOf(id) {
      const sc = schemas().find(s => s.id === id);
      if (!sc) throw gerr('NO_TABLE', `no table ${id}`);
      return sc;
    }

    function keyOf(sc, id) {
      return sc.source === TrackingSources ? TrackingSources.key(ctx, id) : sc.source.key(ctx);
    }

    function retire(slot) {
      slot.ctrl.abort();
      if (slot.token && runner) runner.drop(slot.token);
    }

    /** The slot of a table for the state on screen now. A slot built for a state that
     *  is gone (another timepoint, another tracking option) is retired: its read is
     *  aborted, its worker copy dropped. A null key (no state on screen to build for)
     *  keeps the slot there is: it is the last state shown. */
    function slotFor(id, force) {
      const sc = schemaOf(id);
      const key = keyOf(sc, id);
      const old = cache.get(id);
      if (old && !force && (old.key === key || key === null)) return old;
      if (old) retire(old);
      notReady.delete(id);
      const slot = { key, ctrl: new AbortController(), promise: null, token: null, sent: new Set(), progress: null, listeners: new Set() };
      const signal = slot.ctrl.signal;
      // One build serves every query waiting on it: each one listens while it waits.
      const onProgress = (f) => {
        slot.progress = f;
        for (const fn of slot.listeners) { try { fn(f); } catch (err) { console.error('[graphs] progress listener failed:', err); } }
      };
      slot.promise = (sc.source === TrackingSources ? TrackingSources.build(ctx, sc, t) : sc.source.build(ctx, sc, { signal, onProgress }))
        .then(async (tb) => {
          if (signal.aborted) throw supersededError();
          if (runner && runner.available) {
            const token = `${id}#${++serial}`;
            const wire = wireTable(tb);
            const loading = runner.load(token, wire.table, wire.transfer);
            // A handed-over buffer is empty here from now on: this copy can no longer compute.
            if (wire.transfer.some(b => b.byteLength === 0)) { tb.cols = {}; tb.detached = true; }
            await loading;
            if (signal.aborted) { runner.drop(token); throw supersededError(); }
            slot.token = token;
          }
          return tb;
        })
        .catch(err => {
          if (cache.get(id) === slot) {
            cache.delete(id);
            if (err && err.code === 'NOT_READY') notReady.set(id, key);
          }
          throw err;
        });
      slot.promise.catch(() => { /* reported to whoever awaits it */ });
      cache.set(id, slot);
      return slot;
    }

    function table(id, o = {}) {
      return slotFor(id, Boolean(o.force)).promise;
    }

    /** Start (or keep) the build of a table for the state on screen now, before a
     *  query queued behind another one gets to it: a read for a state the user has
     *  left is aborted at once instead of when the queue reaches it. */
    function touch(id) {
      try { slotFor(id, false); } catch (_) { /* the query will report it */ }
    }

    async function sendLazyColumns(slot, tb, spec) {
      for (const id of specIds(spec)) {
        if (slot.sent.has(id) || !tb.lazy || typeof tb.lazy[id] !== 'function') continue;
        const col = Engine.colOf(tb, id);
        if (!col) continue;
        await runner.column(slot.token, id, col);
        slot.sent.add(id);
      }
    }

    function dropAll() {
      for (const slot of cache.values()) retire(slot);
      cache.clear();
    }

    async function compute(tableId, spec, o = {}) {
      let force = Boolean(o.force);
      for (let attempt = 0; ; attempt++) {
        const slot = slotFor(tableId, force);
        force = false;
        const listen = typeof o.onProgress === 'function' ? o.onProgress : null;
        try {
          let tb;
          if (listen) {
            slot.listeners.add(listen);
            if (slot.progress !== null) { try { listen(slot.progress); } catch (err) { console.error('[graphs] progress listener failed:', err); } }
          }
          try { tb = await slot.promise; } finally { if (listen) slot.listeners.delete(listen); }
          let result;
          if (slot.token) {
            await sendLazyColumns(slot, tb, spec);
            result = await runner.compute(slot.token, spec);
          } else if (tb.detached) {
            throw gerr('WORKER_FAILED', 'the table was handed to a worker that is gone');
          } else {
            result = Engine.compute(tb, spec);
          }
          return Object.assign(result, { info: tb.info || null });
        } catch (err) {
          // The worker died with the tables it held: build them again, on this page.
          if (err && err.code === 'WORKER_FAILED' && attempt === 0) { dropAll(); continue; }
          throw err;
        }
      }
    }

    function stale(id) {
      const sc = schemas().find(s => s.id === id);
      if (!sc) return false;
      const key = keyOf(sc, id);
      const slot = cache.get(id);
      if (!slot) return key !== null && notReady.has(id) && notReady.get(id) !== key;
      return key !== null && slot.key !== key;
    }

    /** The key the table would be built for now (null without such a table). */
    function check(id, spec) {
      Engine.checkSpec(schemaOf(id), spec);
    }

    function currentKey(id) {
      const sc = schemas().find(s => s.id === id);
      return sc ? keyOf(sc, id) : null;
    }

    function reset() {
      dropAll();
      notReady.clear();
      schemasMemo = null;
      trackingMemo.key = null;
    }

    return {
      describe, table, touch, compute, check, stale, currentKey, schemaSig, cursorMinutes, reset,
      dispose() { reset(); if (runner) runner.dispose(); }
    };
  }

  // ════════════════════════════════════════════════════════════════════
  // UI — one panel for a page, one drawer for Compare
  // ════════════════════════════════════════════════════════════════════
  //
  // host = { t, multi, describe() → { tables: [...] } (the union across datasets in
  //          Compare), compute(tableId, spec, { onProgress }) → Promise<result>
  //          (onProgress(f): fraction of the volume read, page mode only), cursor(), datasets()?,
  //          onNotes? }

  let plotlyPromise = null;
  function ensurePlotly() {
    if (window.Plotly) return Promise.resolve(window.Plotly);
    // The core loads it once for every plugin of the page.
    if (typeof PluginRegistry !== 'undefined' && typeof PluginRegistry.loadVendor === 'function') return PluginRegistry.loadVendor('plotly');
    if (plotlyPromise) return plotlyPromise;
    // A core older than loadVendor: load it here, joining a tag another plugin has in flight.
    plotlyPromise = new Promise((resolve, reject) => {
      // Plotly writes its CSS into <style id="plotly.js-style-global"> at load; under
      // the nonce-locked CSP that element has to be created by the registry first.
      if (typeof PluginRegistry !== 'undefined' && PluginRegistry.ensureNoncedStyle) PluginRegistry.ensureNoncedStyle('plotly.js-style-global');
      let script = Array.from(document.querySelectorAll('script[data-vendor-state="loading"]'))
        .find(s => s.getAttribute('src') === PLOTLY_SRC) || null;
      if (!script) {
        script = document.createElement('script');
        script.src = PLOTLY_SRC;
        script.integrity = PLOTLY_SRI;
        script.crossOrigin = 'anonymous';
        script.setAttribute('data-vendor-state', 'loading');
        document.head.appendChild(script);
      }
      const tag = script;
      tag.addEventListener('load', () => {
        tag.setAttribute('data-vendor-state', 'loaded');
        if (window.Plotly) resolve(window.Plotly); else reject(new Error('Plotly did not define itself'));
      });
      tag.addEventListener('error', () => { tag.remove(); reject(new Error('Plotly failed to load')); });
    }).catch(err => { plotlyPromise = null; throw err; });
    return plotlyPromise;
  }

  function cssVar(name, fallback) {
    try {
      const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
      return v || fallback;
    } catch (_) { return fallback; }
  }

  function isDark() {
    try { if (typeof Theme !== 'undefined' && Theme.isDark) return Boolean(Theme.isDark()); } catch (_) { /* fall through */ }
    return document.documentElement.getAttribute('data-theme') === 'dark';
  }

  // Rules the controls need on every host page (viewer, 2D, Compare): the chips. The style
  // element is created by the registry with the page nonce; the rules are inserted into its sheet.
  const STYLE_RULES = [
    '.graphs-chip{display:inline-flex;align-items:center;gap:6px;max-width:100%;padding:3px 10px;font:inherit;font-size:12px;line-height:1.35;text-align:left;white-space:normal;overflow-wrap:anywhere;border:1px solid var(--border-subtle,rgba(128,128,128,.45));border-radius:999px;background:transparent;color:var(--text-primary,inherit);cursor:pointer;--graphs-swatch-ring:var(--border-subtle,rgba(128,128,128,.45))}',
    '.graphs-chip:hover{background:color-mix(in srgb,var(--text-primary,#888) 9%,transparent)}',
    '.graphs-chip:focus-visible{outline:2px solid var(--color-primary,#4a8);outline-offset:2px}',
    '.graphs-chip.is-on{background:var(--color-primary-strong,var(--color-primary,#2a78d6));border-color:var(--color-primary-strong,var(--color-primary,#2a78d6));color:var(--color-on-primary,#fff);font-weight:600;--graphs-swatch-ring:#fff}',
    '.graphs-chip.is-on:hover{filter:brightness(1.08)}'
  ];
  function ensureStyles() {
    try {
      if (typeof PluginRegistry !== 'undefined' && PluginRegistry.ensureNoncedStyle) PluginRegistry.ensureNoncedStyle('graphs-plugin-style');
      const el = document.getElementById('graphs-plugin-style');
      if (!el || !el.sheet || el.dataset.filled) return;
      for (const rule of STYLE_RULES) { try { el.sheet.insertRule(rule, el.sheet.cssRules.length); } catch (_) { /* a rule this browser refuses */ } }
      el.dataset.filled = '1';
    } catch (_) { /* no document (a test) or a page that forbids it: the controls stay usable, plainer */ }
  }

  const FIELD = 'display:flex;flex-direction:column;gap:2px;min-width:0;font-size:11px;color:var(--text-secondary)';
  const CONTROL = 'width:100%;min-width:0;padding:4px 6px;font-size:12px;border:1px solid var(--border-subtle);border-radius:var(--radius-sm,4px);background:var(--bg-surface,transparent);color:var(--text-primary)';

  const UI_SPEC_DEFAULTS = Object.freeze({ x: null, y: [], agg: 'mean', group: null, bins: 0, threshold: 0, signalOnly: false, band: false, normalize: 'none', yScale: 'linear', xScale: 'linear' });
  const NORMALIZE_MODES = ['none', 'max', 'sum', 'first'];
  const ID_MAX = 200;

  function cleanBins(v) {
    const b = Number(v);
    return Number.isFinite(b) && b >= 2 ? Math.min(MAX_BINS, Math.round(b)) : 0;
  }
  function cleanThreshold(v) { return clamp(Number(v) || 0, 0, 254); }
  const cleanId = (v) => (typeof v === 'string' && v.length <= ID_MAX ? v : null);

  /** The controls' spec from a value that came from outside the panel — a workspace,
   *  a shared #state= link, the Compare state, a preset — field by field over `base`:
   *  it is written back into the controls' markup and into the address bar, so only
   *  the known fields with values the controls can hold survive. */
  function sanitizeUiSpec(src, base = UI_SPEC_DEFAULTS) {
    const out = { ...UI_SPEC_DEFAULTS, ...base, y: Array.isArray(base.y) ? base.y.slice() : [] };
    if (!src || typeof src !== 'object') return out;
    const has = (k) => Object.prototype.hasOwnProperty.call(src, k);
    if (has('x')) out.x = cleanId(src.x);
    if (has('group')) out.group = cleanId(src.group);
    if (has('y')) out.y = Array.isArray(src.y) ? src.y.filter(v => cleanId(v) !== null).slice(0, 64) : [];
    if (has('agg') && (AGGS.includes(src.agg) || src.agg === 'points' || src.agg === 'density')) out.agg = src.agg;
    if (has('bins')) out.bins = cleanBins(src.bins);
    if (has('threshold')) out.threshold = cleanThreshold(src.threshold);
    if (has('signalOnly')) out.signalOnly = src.signalOnly === true;
    if (has('band')) out.band = src.band === true;
    if (has('normalize') && NORMALIZE_MODES.includes(src.normalize)) out.normalize = src.normalize;
    if (has('yScale') && (src.yScale === 'linear' || src.yScale === 'log')) out.yScale = src.yScale;
    if (has('xScale') && (src.xScale === 'linear' || src.xScale === 'log')) out.xScale = src.xScale;
    return out;
  }

  function createUI(root, host) {
    const t = host.t;
    ensureStyles();
    const st = {
      table: null, preset: null,
      spec: sanitizeUiSpec(null),
      colorBy: 'dataset'
    };
    let desc = { tables: [] };
    let seq = 0, timer = null, last = null, gd = null, destroyed = false;
    const el = (sel) => root.querySelector(sel);

    const tableOf = (id) => desc.tables.find(x => x.id === id) || null;
    const varOf = (tb, id) => (tb ? tb.vars.find(v => v.id === id) : null) || null;

    function presetAvailable(tb, p) {
      let need = 0;
      const spec = (p && p.spec) || {};
      for (const id of [spec.x, ...(Array.isArray(spec.y) ? spec.y : [])]) {
        const m = /^@int\[(\d+)\]$/.exec(typeof id === 'string' ? id : '');
        if (m) need = Math.max(need, +m[1] + 1);
      }
      return sharedChannels(tb).length >= need;
    }
    const visiblePresets = (tb) => (tb.presets || []).filter(p => presetAvailable(tb, p));

    function opt(value, label, sel) { return `<option value="${escapeHtml(value)}"${sel ? ' selected' : ''}>${escapeHtml(label)}</option>`; }

    function aggOptions(tb) {
      const s = st.spec;
      const xInt = s.x === INT;
      const list = xInt ? ['count', 'measure'] : AGGS.slice();
      const xv = varOf(tb, s.x);
      const out = list.map(a => ({ v: a, l: t(`agg_${a}`) }));
      if (!xInt && xv && xv.kind === 'num') { out.push({ v: 'points', l: t('agg_points') }); out.push({ v: 'density', l: t('agg_density') }); }
      return out;
    }

    function renderControls() {
      const box = el('[data-g="controls"]');
      if (!box) return;
      const a = document.activeElement;
      const focus = a && box.contains(a) ? { y: a.getAttribute('data-y'), g: a.getAttribute('data-g') } : null;
      renderControlsInner();
      if (!focus) return;
      const esc = (v) => (window.CSS && CSS.escape ? CSS.escape(v) : String(v).replace(/["\\]/g, '\\$&'));
      const sel = focus.y !== null ? `[data-y="${esc(focus.y)}"]` : (focus.g ? `[data-g="${esc(focus.g)}"]` : null);
      const target = sel ? box.querySelector(sel) : null;
      if (target && typeof target.focus === 'function') target.focus({ preventScroll: true });
    }

    function renderControlsInner() {
      const tb = tableOf(st.table);
      const box = el('[data-g="controls"]');
      if (!box) return;
      if (!tb) { box.innerHTML = `<div class="text-xs text-muted">${escapeHtml(t('noTables'))}</div>`; return; }
      const s = st.spec;
      const nums = tb.vars.filter(v => v.kind === 'num');
      const cats = tb.vars.filter(v => v.kind === 'cat' && v.id !== s.x);
      const ints = tb.vars.filter(v => v.ch);
      const isHeat = s.agg === 'density', isPts = s.agg === 'points';
      const yIsOptional = s.agg === 'count' || s.agg === 'measure';
      const xOpts = [
        ...(ints.length ? [{ v: INT, l: t('x_allChannels') }] : []),
        { v: ALL, l: t('x_summary') },
        ...tb.vars.map(v => ({ v: v.id, l: axisTitle(v.label, v.unit) }))
      ];
      const showThr = tb.vars.some(v => v.intensity) && (COUNT_FAMILY.has(s.agg) || isHeat || s.signalOnly);
      const showSig = !isHeat && !isPts && !COUNT_FAMILY.has(s.agg) && tb.vars.some(v => v.intensity) && s.x !== INT;
      const presets = visiblePresets(tb);
      const binsValue = cleanBins(s.bins) || '';
      const thr = cleanThreshold(s.threshold);
      box.innerHTML = `
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px;align-items:end">
          <label style="${FIELD}"><span>${escapeHtml(t('data'))}</span>
            <select style="${CONTROL}" data-g="table">${desc.tables.map(x => opt(x.id, x.label, x.id === st.table)).join('')}</select></label>
          <label style="${FIELD}"><span>${escapeHtml(t('preset'))}</span>
            <select style="${CONTROL}" data-g="preset">${opt('', t('presetCustom'), !st.preset)}${presets.map(p => opt(p.id, t(`preset_${p.id}`), st.preset === p.id)).join('')}</select></label>
          <label style="${FIELD}"><span>${escapeHtml(t('xAxis'))}</span>
            <select style="${CONTROL}" data-g="x">${xOpts.map(o => opt(o.v, o.l, o.v === s.x)).join('')}</select></label>
          <label style="${FIELD}"><span>${escapeHtml(t('agg'))}</span>
            <select style="${CONTROL}" data-g="agg">${aggOptions(tb).map(o => opt(o.v, o.l, o.v === s.agg)).join('')}</select></label>
          ${cats.length ? `<label style="${FIELD}"><span>${escapeHtml(t('group'))}</span>
            <select style="${CONTROL}" data-g="group">${opt('', t('groupNone'), !s.group)}${cats.map(v => opt(v.id, v.label, v.id === s.group)).join('')}</select></label>` : ''}
          ${isHeat || s.x === INT ? '' : `<label style="${FIELD}"><span>${escapeHtml(t('normalize'))}</span>
            <select style="${CONTROL}" data-g="normalize" ${isPts ? 'disabled' : ''}>${['none', 'max', 'sum', 'first'].map(n => opt(n, t(`norm_${n}`), n === s.normalize)).join('')}</select></label>`}
          <label style="${FIELD}"><span>${escapeHtml(t('bins'))}</span>
            <input style="${CONTROL}" type="number" min="2" max="${MAX_BINS}" step="1" placeholder="${escapeHtml(t('auto'))}" value="${binsValue}" data-g="bins"></label>
          <label style="${FIELD}"><span>${escapeHtml(t('yScale'))} / ${escapeHtml(t('xScale'))}</span>
            <span style="display:flex;gap:4px"><select style="${CONTROL}" data-g="yScale" aria-label="${escapeHtml(t('yScale'))}">${opt('linear', t('linear'), s.yScale === 'linear')}${opt('log', t('log'), s.yScale === 'log')}</select>
            ${isHeat || s.x === ALL || s.x === INT || varOf(tb, s.x)?.kind === 'cat' ? '' : `<select style="${CONTROL}" data-g="xScale" aria-label="${escapeHtml(t('xScale'))}">${opt('linear', t('linear'), s.xScale === 'linear')}${opt('log', t('log'), s.xScale === 'log')}</select>`}</span></label>
          ${host.multi ? `<label style="${FIELD}"><span>${escapeHtml(t('colorBy'))}</span>
            <select style="${CONTROL}" data-g="colorBy">${opt('dataset', t('colorDataset'), st.colorBy === 'dataset')}${opt('series', t('colorSeries'), st.colorBy === 'series')}</select></label>` : ''}
        </div>
        ${s.x === INT ? '' : `<div style="margin-top:8px"><div style="font-size:11px;color:var(--text-secondary);margin-bottom:3px">${escapeHtml(isHeat ? t('yOne') : yIsOptional ? t('yOptional') : t('yAxis'))}</div>
          <div style="display:flex;flex-wrap:wrap;gap:4px" data-g="ychips">${nums.map(v => {
            const on = s.y.includes(v.id) || (s.y.includes(INT) && commonChannels(tb).includes(v.id));
            const partial = tb.total > 1 && v.haveCount !== undefined && v.haveCount < tb.total ? ` (${v.haveCount}/${tb.total})` : '';
            // In Compare the colour comes from a panel's answer: checked again here.
            const sw = readable(v.color, isDark()) || safeColor(v.color);
            return `<button type="button" class="graphs-chip${on ? ' is-on' : ''}" data-y="${escapeHtml(v.id)}" aria-pressed="${on}">${sw ? `<span aria-hidden="true" style="flex:none;width:9px;height:9px;border-radius:50%;background:${escapeHtml(sw)};box-shadow:0 0 0 1.5px var(--graphs-swatch-ring,transparent)"></span>` : ''}<span>${escapeHtml(v.label + partial)}</span></button>`;
          }).join('')}</div></div>`}
        <div style="display:flex;flex-wrap:wrap;gap:14px;margin-top:8px;align-items:center;font-size:12px">
          ${showThr ? `<label style="display:flex;align-items:center;gap:6px"><span>${escapeHtml(t('threshold'))}</span><input type="range" min="0" max="254" step="1" value="${thr}" data-g="threshold" style="width:120px"><output data-g="thrOut">${thr}</output></label>` : ''}
          ${showSig ? `<label style="display:flex;align-items:center;gap:6px"><input type="checkbox" data-g="signalOnly" ${s.signalOnly ? 'checked' : ''}>${escapeHtml(t('signalOnly'))}</label>` : ''}
          ${s.agg === 'mean' && !isHeat ? `<label style="display:flex;align-items:center;gap:6px"><input type="checkbox" data-g="band" ${s.band ? 'checked' : ''}>${escapeHtml(t('band'))}</label>` : ''}
        </div>`;
    }

    function setStatus(msg, kind) {
      const e = el('[data-g="status"]');
      if (!e) return;
      e.textContent = msg || '';
      e.style.color = kind === 'error' ? 'color-mix(in srgb, var(--color-error, #e34948) 60%, var(--text-primary, #000))' : 'var(--text-secondary)';
    }

    function setNotes(list) {
      const e = el('[data-g="notes"]');
      if (!e) return;
      e.innerHTML = (list || []).map(n => `<div>${escapeHtml(n)}</div>`).join('');
    }

    function applyPreset(id) {
      const tb = tableOf(st.table);
      const p = tb && visiblePresets(tb).find(x => x.id === id);
      if (!p) return;
      st.preset = id;
      const spec = JSON.parse(JSON.stringify(p.spec));
      // "@int[k]" = the k-th channel every dataset has: the pickers show a real variable.
      const nth = (tok) => { const m = /^@int\[(\d+)\]$/.exec(tok); return m ? (sharedChannels(tb)[+m[1]] || tok) : tok; };
      spec.x = nth(spec.x);
      spec.y = (spec.y || []).map(nth);
      st.spec = sanitizeUiSpec(spec, { ...UI_SPEC_DEFAULTS, threshold: st.spec.threshold });
    }

    function chooseTable(id) {
      st.table = id;
      const tb = tableOf(id);
      st.preset = null;
      const first = tb ? visiblePresets(tb)[0] : null;
      if (first) applyPreset(first.id);
      else if (tb) st.spec = sanitizeUiSpec({ x: tb.defaults?.x || null, y: tb.defaults?.y || [], agg: tb.defaults?.agg || 'mean', group: tb.defaults?.group || null }, st.spec);
    }

    function reconcileSpec() {
      const tb = tableOf(st.table);
      if (!tb) return;
      const ids = new Set(tb.vars.map(v => v.id));
      const isToken = (id) => id === INT || id === ALL || /^@int(\[\d+\])?$/.test(String(id));
      const s = st.spec;
      let changed = false;
      if (!(isToken(s.x) || ids.has(s.x))) { s.x = (tb.defaults && tb.defaults.x && ids.has(tb.defaults.x)) ? tb.defaults.x : (tb.vars[0] ? tb.vars[0].id : null); changed = true; }
      const y = s.y.filter(id => isToken(id) || ids.has(id));
      if (y.length !== s.y.length) { s.y = y; changed = true; }
      if (s.group && !(ids.has(s.group) && varOf(tb, s.group).kind === 'cat')) { s.group = null; changed = true; }
      if (changed) st.preset = null;
    }

    function schedule(delay = 90) {
      clearTimeout(timer);
      timer = setTimeout(draw, delay);
    }

    function friendly(err) {
      const code = err && err.code;
      if (code === 'NOT_READY') return t('err_notReady');
      if (code === 'NO_DATA' || code === 'NO_VARIABLE' || code === 'NO_TABLE') return t('err_noData');
      if (code === 'COMPARE_TIMEOUT') return t('err_timeout');
      return t('err_generic');
    }

    async function draw() {
      if (destroyed) return;
      const tb = tableOf(st.table);
      const target = el('[data-g="plot"]');
      if (!tb || !target) return;
      const mine = ++seq;
      setStatus(t('computing'));
      let result;
      try {
        result = await host.compute(st.table, st.spec, {
          onProgress: (f) => { if (mine === seq && !destroyed && f < 1) setStatus(t('reading', { pct: Math.round(100 * f) })); }
        });
      } catch (err) {
        // A superseded query: the one that replaced it draws.
        if (mine !== seq || destroyed || (err && err.code === 'SUPERSEDED')) return;
        if (!(err && err.name === 'AbortError')) console.error('[graphs] query failed:', err);
        setStatus(friendly(err), 'error');
        setNotes([]);
        return;
      }
      if (mine !== seq || destroyed) return;
      let Plotly;
      try { Plotly = await ensurePlotly(); } catch (err) {
        console.error('[graphs] Plotly unavailable:', err);
        setStatus(t('err_plotly'), 'error');
        return;
      }
      if (mine !== seq || destroyed) return;
      last = result;
      const empty = result.kind === 'heat' ? !(result.heats || [result.heat]).some(h => h && h.z.some(r => r.some(Boolean)))
        : !result.series.length;
      const cur = host.cursor ? host.cursor() : null;
      const isT = result.x && (result.x.id === 't');
      const lang = (typeof I18n !== 'undefined' && I18n.getLanguage) ? I18n.getLanguage() : undefined;
      const plot = buildPlot(result, {
        nf: numberFormatter(lang), separators: separatorsFor(lang),
        dark: isDark(), t, multi: host.multi && (result.datasets || 0) > 1, colorBy: st.colorBy,
        text: cssVar('--text-secondary', undefined), grid: cssVar('--border-subtle', undefined),
        cursorX: isT && cur ? cur.value : null,
        cursorLabel: cur ? t('cursorNow') : '', spec: result.spec
      });
      try {
        await Plotly.react(target, plot.data, plot.layout, { displayModeBar: false, responsive: true });
      } catch (err) {
        console.error('[graphs] plot failed:', err);
        setStatus(t('err_plotly'), 'error');
        return;
      }
      if (mine !== seq || destroyed) return;
      gd = target;
      setStatus(empty ? t('err_noData') : (result.statusText || ''));
      const notes = (result.notes || []).map(n => t(`note_${n}`, { n: result.stride || '' })).filter(x => x && !x.startsWith('note_'));
      (result.extraNotes || []).forEach(n => notes.push(n));
      setNotes(notes);
    }

    function onChange(e) {
      const g = e.target.getAttribute && e.target.getAttribute('data-g');
      if (!g) return;
      pending = null; // a choice made now outranks a restored one still waiting
      const s = st.spec;
      const v = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
      let structural = false;
      switch (g) {
        case 'table': chooseTable(v); structural = true; break;
        case 'preset': if (v) applyPreset(v); else st.preset = null; structural = true; break;
        case 'x': s.x = v; st.preset = null; structural = true; break;
        case 'agg': s.agg = v; st.preset = null; structural = true; break;
        case 'group': s.group = v || null; st.preset = null; break;
        case 'normalize': s.normalize = v; st.preset = null; break;
        case 'bins': s.bins = cleanBins(v); break;
        case 'yScale': s.yScale = v; break;
        case 'xScale': s.xScale = v; break;
        case 'threshold': s.threshold = cleanThreshold(v); { const o = el('[data-g="thrOut"]'); if (o) o.textContent = String(s.threshold); } break;
        case 'signalOnly': s.signalOnly = Boolean(v); break;
        case 'band': s.band = Boolean(v); break;
        case 'colorBy': st.colorBy = v; break;
        default: return;
      }
      if (structural) renderControls();
      schedule(g === 'threshold' ? 140 : 60);
    }

    function onClick(e) {
      const chip = e.target.closest && e.target.closest('[data-y]');
      if (chip) {
        const id = chip.getAttribute('data-y');
        const tb = tableOf(st.table);
        let y = st.spec.y.flatMap(k => (k === INT ? commonChannels(tb) : [k]));
        if (st.spec.agg === 'density') y = [id];
        else y = y.includes(id) ? y.filter(k => k !== id) : [...y, id];
        st.spec.y = y;
        st.preset = null;
        renderControls();
        schedule();
        return;
      }
      const act = e.target.closest && e.target.closest('[data-g-act]');
      if (!act) return;
      const a = act.getAttribute('data-g-act');
      if (a === 'refresh') { host.invalidate && host.invalidate(); schedule(0); }
      else if (a === 'csv') exportCsv();
      else if (a === 'png') exportPng();
    }

    function purgePlot() {
      if (gd && window.Plotly) { try { Plotly.purge(gd); } catch (_) { /* nothing to purge */ } }
      gd = null;
    }

    function stamp() { return new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-'); }

    function download(blob, name) {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    }

    function exportCsv() {
      if (!last) return;
      download(new Blob([Engine.toCsv(last)], { type: 'text/csv;charset=utf-8' }), `graph-${st.table}-${stamp()}.csv`);
    }

    async function exportPng() {
      if (!gd || !window.Plotly) return;
      try {
        const url = await Plotly.toImage(gd, { format: 'png', width: 1600, height: 900, scale: 2 });
        download(dataUrlToBlob(url), `graph-${st.table}-${stamp()}.png`);
      } catch (err) { console.error('[graphs] PNG export failed:', err); setStatus(t('err_export'), 'error'); }
    }

    root.addEventListener('change', onChange);
    root.addEventListener('input', (e) => { if (e.target.getAttribute && e.target.getAttribute('data-g') === 'threshold') onChange(e); });
    root.addEventListener('click', onClick);
    const offTheme = (typeof Theme !== 'undefined' && typeof Theme.onChange === 'function')
      ? Theme.onChange(() => { if (destroyed) return; renderControls(); if (gd) schedule(0); })
      : null;

    // A state restored before the host described its tables (a closed panel): applied
    // by the next description, so reopening shows the saved choices.
    let pending = null;
    function applyState(s) {
      if (typeof s.table === 'string' && tableOf(s.table)) st.table = s.table;
      if (s.spec && typeof s.spec === 'object') st.spec = sanitizeUiSpec(s.spec, st.spec);
      if (s.colorBy === 'series' || s.colorBy === 'dataset') st.colorBy = s.colorBy;
      st.preset = cleanId(s.preset);
    }

    return {
      /** Re-read what the host offers and redraw. */
      refreshDescription() {
        desc = host.describe();
        // A description without tables yet (panels still loading) keeps the restored choices
        // waiting; only a description that lacks the saved table drops them.
        if (pending && (tableOf(pending.table) || desc.tables.length)) {
          if (tableOf(pending.table)) applyState(pending);
          pending = null;
        }
        if (!tableOf(st.table)) chooseTable(desc.tables[0] ? desc.tables[0].id : null);
        reconcileSpec();
        renderControls();
        schedule(0);
      },
      redraw: () => schedule(0),
      relabel() { renderControls(); schedule(0); },
      /** The choices on screen, or the restored ones still waiting for the description
       *  (a URL sync or a saved workspace before the first open must carry them). */
      getState: () => JSON.parse(JSON.stringify(pending ? {
        table: pending.table,
        spec: pending.spec && typeof pending.spec === 'object' ? sanitizeUiSpec(pending.spec, st.spec) : st.spec,
        colorBy: pending.colorBy === 'series' || pending.colorBy === 'dataset' ? pending.colorBy : st.colorBy,
        preset: cleanId(pending.preset)
      } : { table: st.table, spec: st.spec, colorBy: st.colorBy, preset: st.preset })),
      /** `draw: false` stores the choices without querying (a closed panel must not
       *  read a table it would then hold); the next refreshDescription draws them. */
      setState(s, { draw = true } = {}) {
        if (!s || typeof s !== 'object') return;
        // Before the description of the tables (a restored workspace, a Compare drawer that has not asked
        // its panels yet) the choices wait for it: applying them now would be undone by the first table chosen.
        if (typeof s.table === 'string' && !tableOf(s.table)) {
          pending = JSON.parse(JSON.stringify(s));
          return;
        }
        pending = null;
        applyState(s);
        reconcileSpec();
        renderControls();
        if (draw) schedule(0);
      },
      getPlot: () => gd,
      getLast: () => last,
      getTable: () => st.table,
      setStatus,
      resize() { if (gd && window.Plotly) { try { Plotly.Plots.resize(gd); } catch (_) { /* detached */ } } },
      /** Drop the plot (its div, data and resize handler) and any draw in flight; the
       *  controls and choices stay, and the next refresh draws again. */
      release() {
        clearTimeout(timer);
        seq++;
        purgePlot();
        last = null;
      },
      destroy() {
        destroyed = true;
        clearTimeout(timer);
        root.removeEventListener('change', onChange);
        root.removeEventListener('click', onClick);
        if (typeof offTheme === 'function') offTheme();
        purgePlot();
      }
    };
  }

  function panelHtml(t, withClose) {
    const btn = (act, icon, key) => `<button type="button" class="btn btn-icon btn-ghost" data-g-act="${act}" title="${escapeHtml(t(key))}" aria-label="${escapeHtml(t(key))}"><i data-lucide="${icon}"></i></button>`;
    return `
      <div class="scientific-panel-header">
        <strong class="flex items-center gap-2"><i data-lucide="line-chart" class="w-4 h-4"></i> <span data-g="title">${escapeHtml(t('panelTitle'))}</span></strong>
        <div class="flex items-center gap-2">
          ${btn('refresh', 'refresh-cw', 'refresh')}${btn('csv', 'file-spreadsheet', 'exportCsv')}${btn('png', 'image', 'exportPng')}
          ${withClose ? `<button type="button" class="btn btn-icon btn-ghost" data-g-close aria-label="${escapeHtml(t('close'))}"><i data-lucide="x"></i></button>` : ''}
        </div>
      </div>
      <div class="graphs-body">
        <div data-g="controls"></div>
        <div data-g="status" class="text-xs" role="status" aria-live="polite" style="min-height:16px;margin-top:6px"></div>
        <div data-g="plot" class="graphs-plot"></div>
        <div data-g="notes" class="text-xs text-muted"></div>
      </div>`;
  }

  // ════════════════════════════════════════════════════════════════════
  // Panel protocol (Compare host ⇄ the page in a panel)
  // ════════════════════════════════════════════════════════════════════

  function plainResult(r) {
    // Structured-clone safe, free of the engine's typed arrays.
    return JSON.parse(JSON.stringify(r, (k, v) => (typeof v === 'number' && !Number.isFinite(v) ? null : v)));
  }

  // ════════════════════════════════════════════════════════════════════
  // Plugin
  // ════════════════════════════════════════════════════════════════════

  const plugin = {
    Engine, buildPlot, mergeResults, shortNames, commonChannels, sharedChannels, specForPanels, Sources, TrackingSources, trackingSchemas, buildTracking, msdRows, neighbourColumn, allSchemas, createProvider, readable, safeColor, PALETTE,
    createUI, sanitizeUiSpec, latestOnly, createWorkerRunner, wireTable, dataUrlToBlob, separatorsFor, numberFormatter, measurementLines,
    _ctx: null, _t: null, _provider: null, _ui: null, _panel: null, _open: false, _mode: 'page',
    _unsubs: [], _pollTimer: null, _lastKey: null, _msgHandler: null, _host: null, _run: null,

    _tr(key, params) { return this._ctx.i18n.t(key, params); },

    init(ctx) {
      this._ctx = ctx;
      const t = (k, p) => ctx.i18n.t(k, p);
      this._t = t;
      if (ctx.context === 'compare') { this._mode = 'compare'; return this._initHost(ctx); }
      this._provider = createProvider(ctx, t, { runner: createWorkerRunner(engineWorkerUrl()) });
      // A photograph switched in place (the 2D page's own browser): its units, labels and
      // tables are the new one's, not the schema the provider memoised for the old one.
      if (ctx.dataset && typeof ctx.dataset.onChange === 'function') {
        const off = ctx.dataset.onChange(() => {
          this._run?.cancel();
          this._provider.reset();
          if (this._open) this._ui?.refreshDescription();
        });
        if (typeof off === 'function') this._unsubs.push(off);
      }
      if (ctx.iframe && ctx.iframe.isIframe && ctx.iframe.isIframe()) { this._mode = 'panel'; this._bindPanel(ctx); return this; }
      this._mode = 'page';
      if (!ctx.ui || !ctx.ui.addCanvasPanel) return this;
      this._panel = ctx.ui.addCanvasPanel({
        id: 'graphs', className: 'graphs-panel', html: panelHtml(t, true),
        bind: (root) => {
          root.querySelector('[data-g-close]')?.addEventListener('click', () => this._setOpen(false));
          const run = latestOnly((table, spec, o) => this._provider.compute(table, spec, o));
          this._run = run;
          this._ui = createUI(root, {
            t, multi: false,
            describe: () => this._provider.describe(),
            compute: (table, spec, o) => {
              // A closed panel holds no table: a draw that slipped past the close stops here.
              if (!this._open) return Promise.reject(supersededError());
              this._provider.touch(table);
              return run(table, spec, { onProgress: o && o.onProgress }).then(r => Object.assign(r, { datasets: 1, statusText: this._statusText(r) }));
            },
            cursor: () => this._provider.cursorMinutes(),
            invalidate: () => this._provider.reset()
          });
        }
      });
      return this;
    },

    /** Called by the registry on a language switch (page, Compare panel and host alike). */
    onLanguageChange() {
      if (this._mode === 'compare') this._host?.relabel();
      // A panel has no UI of its own, but its tables carry the translated variable
      // names it describes and computes with: build them again in the new language.
      else if (this._mode === 'panel') this._provider?.reset();
      else this._relabel();
    },

    _statusText(r) {
      const info = r.info;
      if (!info) return '';
      const nf = numberFormatter(languageOf(this._ctx));
      if (info.lines) return this._t('lineInfo', { n: info.lines, size: nf(info.step, info.step < 10 ? 2 : 1) });
      if (info.voxelSize) {
        const v = info.voxelSize;
        return this._t('scanInfo', { x: info.dims.x, y: info.dims.y, z: info.dims.z, size: [v.x, v.y, v.z].map(a => nf(+a, a < 10 ? 2 : 1)).join(' × ') });
      }
      if (info.scale !== undefined && info.scale < 1) return this._t('pixelInfo', { x: info.dims.x, y: info.dims.y });
      return '';
    },

    _relabel() {
      if (!this._panel) return;
      this._run?.cancel();
      this._provider.reset();
      const body = this._panel.root;
      const keep = this._ui ? this._ui.getState() : null;
      this._ui?.release();
      body.innerHTML = panelHtml(this._t, true);
      body.querySelector('[data-g-close]')?.addEventListener('click', () => this._setOpen(false));
      if (window.lucide) lucide.createIcons({ nodes: [body] });
      // The listeners sit on the root, which survives; only the markup changed.
      if (this._open) { this._ui.refreshDescription(); if (keep) this._ui.setState(keep); }
    },

    _setOpen(on) {
      this._open = Boolean(on);
      this._panel?.toggle(this._open);
      if (typeof PluginRegistry !== 'undefined') PluginRegistry.syncToolbarButton('graphs', { active: this._open });
      clearInterval(this._pollTimer);
      this._pollTimer = null;
      this._lastKey = null;
      this._lastSig = undefined;
      if (this._open) {
        this._ui?.refreshDescription();
        this._lastSig = this._provider.schemaSig?.();
        // A timelapse: the volume on screen changes with the timepoint; follow it.
        this._pollTimer = setInterval(() => this._follow(), 800);
      } else {
        // A closed panel holds nothing: a lossless level and its position columns can
        // take over 100 MB beside the viewer's own memory. Reopening reads them again.
        this._ui?.release();
        this._run?.cancel();
        this._provider?.reset();
      }
      this._ctx.ui.scheduleResize?.();
    },

    /** Redraw once the state the table depends on has held for a whole tick: a
     *  timelapse that plays changes timepoint faster than a level can be read, and
     *  every frame it passed would otherwise start a lossless read of a whole level. */
    _follow() {
      if (!this._open || !this._ui) return;
      // Measurements come and go: the "along a measurement" table with them.
      const sig = this._provider.schemaSig?.();
      if (this._lastSig !== undefined && sig !== this._lastSig) { this._lastSig = sig; this._ui.refreshDescription(); return; }
      this._lastSig = sig;
      const tb = this._ui.getTable();
      const key = tb ? this._provider.currentKey(tb) : null;
      const settled = key !== null && key === this._lastKey;
      this._lastKey = key;
      if (!settled || !this._provider.stale(tb)) return;
      this._ui.redraw();
    },

    activate() {
      this._setOpen(!this._open);
      return { active: this._open };
    },

    deactivate() { this._setOpen(false); },

    getState() {
      if (this._mode === 'compare') return { open: this._open, ui: this._host ? this._host.ui.getState() : null };
      return { open: this._open, ui: this._ui ? this._ui.getState() : null };
    },

    setState(s) {
      if (!s || typeof s !== 'object') return;
      if (this._mode === 'page') {
        this._setOpen(Boolean(s.open));
        // Closed: keep the choices for the reopen, read nothing now.
        if (s.ui && this._ui) this._ui.setState(s.ui, { draw: this._open });
      } else if (this._mode === 'compare' && this._host) {
        this._host.setOpen(Boolean(s.open));
        if (s.ui) this._host.ui.setState(s.ui, { draw: this._open });
      }
    },

    reset() { if (this._mode === 'page') this._setOpen(false); },

    /** The plot on screen, for the Download Center's graph exports. */
    getGraph() { return this._open && this._ui ? this._ui.getPlot() : null; },

    dispose() {
      clearInterval(this._pollTimer);
      this._lastKey = null;
      this._unsubs.forEach(fn => { try { fn(); } catch (_) { /* gone */ } });
      this._unsubs = [];
      if (this._msgHandler) window.removeEventListener('message', this._msgHandler);
      this._msgHandler = null;
      this._ui?.destroy();
      this._ui = null;
      this._panel?.remove();
      this._panel = null;
      this._host?.dispose();
      this._host = null;
      this._run?.cancel();
      this._run = null;
      this._provider?.dispose();
      this._open = false;
    },

    // — A panel of Compare: answer the host —

    _bindPanel(ctx) {
      const index = ctx.iframe.panelIndex();
      const reply = (msg) => {
        try { window.parent.postMessage({ ...msg, sourceIndex: index }, Utils.trustedTargetOrigin()); } catch (_) { /* host gone */ }
      };
      // This frame shares the host's thread: never let queries pile up behind each other.
      const run = latestOnly((table, spec) => this._provider.compute(table, spec));
      this._run = run;
      this._msgHandler = (e) => {
        if (e.source !== window.parent || window.parent === window) return;
        if (typeof Utils !== 'undefined' && Utils.isTrustedMessageOrigin && !Utils.isTrustedMessageOrigin(e)) return;
        const d = e.data;
        if (!d || d.type !== 'REQUEST_GRAPH_DATA' || typeof d.requestId !== 'string') return;
        if (d.sourceIndex !== undefined && d.sourceIndex !== null && String(d.sourceIndex) === String(index)) return;
        const requestId = d.requestId;
        const fail = (err) => reply({ type: 'GRAPH_DATA', requestId, ok: false, error: String(err && err.code || 'GRAPH_FAILED'), code: err && err.code || 'GRAPH_FAILED' });
        try {
          if (d.op === 'describe') {
            reply({ type: 'GRAPH_DATA', requestId, ok: true, description: plainResult(this._provider.describe()) });
          } else if (d.op === 'release') {
            // The drawer closed: a table is tens to hundreds of MB, kept for nobody.
            this._run?.cancel();
            this._provider.reset();
            reply({ type: 'GRAPH_DATA', requestId, ok: true });
          } else if (d.op === 'key') {
            // What a table depends on now (the frame on screen of a timelapse), without reading it.
            reply({ type: 'GRAPH_DATA', requestId, ok: true, key: this._provider.currentKey(String(d.table)) });
          } else if (d.op === 'compute') {
            const table = String(d.table);
            const spec = d.spec && typeof d.spec === 'object' ? d.spec : {};
            // This panel must answer THIS question or say it cannot: not another one of its own.
            this._provider.check(table, spec);
            this._provider.touch(table);
            run(table, spec).then(
              (r) => reply({ type: 'GRAPH_DATA', requestId, ok: true, result: plainResult(r), statusText: this._statusText(r), key: this._provider.currentKey(table) }),
              // An aborted read: the table was dropped for a newer state or language.
              (err) => (err && (err.code === 'SUPERSEDED' || err.name === 'AbortError')
                ? reply({ type: 'GRAPH_DATA', requestId, ok: false, error: 'SUPERSEDED', code: 'SUPERSEDED' })
                : fail(err))
            );
          } else fail({ code: 'BAD_REQUEST' });
        } catch (err) { fail(err); }
      };
      window.addEventListener('message', this._msgHandler);
    },

    // — The Compare page —

    _initHost(ctx) {
      const t = this._t;
      const slots = new Map();               // panel index -> palette slot (kept while the panel lives)
      const descriptions = new Map();        // panel index -> its description
      const slotOf = (index) => {
        if (slots.has(index)) return slots.get(index);
        const used = new Set(slots.values());
        let n = 0;
        while (used.has(n)) n++;
        slots.set(index, n);
        return n;
      };
      const live = () => ctx.panels.list().filter(p => p.ready && !p.failed);
      const lastKeys = new Map();            // panel index -> the state its last answer was computed for
      const refused = new Map();             // panel index -> when it last failed to describe itself

      const fetchDescriptions = async () => {
        const ps = live();
        for (const k of [...descriptions.keys()]) if (!ps.some(p => p.index === k)) { descriptions.delete(k); slots.delete(k); }
        await Promise.all(ps.map(async (p) => {
          const known = descriptions.get(p.index);
          // Asked again after a language switch until the panel answers in the new language.
          if (known && known.id === p.id && (!known.lang || known.lang === languageOf(ctx))) return;
          // A panel that did not answer (loaded without the plugin) is not waited for again at once.
          if (!known && refused.has(p.index) && Date.now() - refused.get(p.index) < 30000) return;
          try {
            const a = await ctx.panels.request(p.index, 'REQUEST_GRAPH_DATA', { op: 'describe' }, { timeoutMs: 8000 });
            descriptions.set(p.index, { ...a.description, id: p.id });
            refused.delete(p.index);
          } catch (err) { refused.set(p.index, Date.now()); /* keep what this panel last said: a slow answer must not empty the pickers */ }
        }));
      };

      /** Union of the panels' tables and variables, by id. A channel's id is its
       *  name, so the same marker lines up across datasets. */
      const union = () => {
        const tables = new Map();
        for (const [index, d] of descriptions) {
          for (const tb of d.tables) {
            let u = tables.get(tb.id);
            if (!u) { u = { id: tb.id, label: tb.label, measureUnit: tb.measureUnit, defaults: tb.defaults, presets: [], vars: [], total: 0 }; tables.set(tb.id, u); }
            u.total++;
            for (const p of tb.presets || []) if (!u.presets.some(x => x.id === p.id)) u.presets.push(p);
            for (const v of tb.vars) {
              let uv = u.vars.find(x => x.id === v.id);
              if (!uv) { uv = { ...v, haveCount: 0 }; u.vars.push(uv); }
              uv.haveCount++;
            }
          }
          void index;
        }
        return { tables: [...tables.values()] };
      };

      const hostApi = {
        t, multi: true,
        describe: union,
        cursor: () => null,
        invalidate: () => descriptions.clear(),
        // One round in flight: a newer draw waits for it and replaces any round still waiting.
        compute: latestOnly(async (tableId, spec) => {
          await fetchDescriptions();
          const ps = live().filter(p => descriptions.get(p.index)?.tables.some(tb => tb.id === tableId));
          if (!ps.length) throw gerr('NOT_READY', 'no panel offers this table');
          // Channels are lined up by name: a bare "every channel" means the ones all datasets have.
          const tb = union().tables.find(x => x.id === tableId);
          const { sent, unresolved } = specForPanels(spec, tb);
          if (unresolved) throw gerr('NO_VARIABLE', 'the datasets share too few channels for this graph');
          const settled = await Promise.allSettled(ps.map(p =>
            ctx.panels.request(p.index, 'REQUEST_GRAPH_DATA', { op: 'compute', table: tableId, spec: sent }, { timeoutMs: 180000 })));
          const results = [];
          const missing = live().filter(p => !ps.some(q => q.index === p.index)).map(p => p.name);
          let superseded = 0;
          // A panel's refusal arrives as a COMPARE_PANEL_ERROR carrying the panel's own code.
          const codeOf = (r) => (r.status === 'rejected' ? (r.reason?.panelCode || r.reason?.code || null) : (r.value?.ok ? null : r.value?.code || null));
          settled.forEach((r, i) => {
            if (r.status === 'fulfilled' && r.value.ok) { results.push({ p: ps[i], res: r.value.result }); if (r.value.key !== undefined) lastKeys.set(ps[i].index, r.value.key); }
            else if (codeOf(r) === 'SUPERSEDED') superseded++;
            else missing.push(ps[i].name);
          });
          if (!results.length && superseded) throw supersededError();
          if (!results.length) {
            const codes = settled.map(codeOf).filter(Boolean);
            // "Still loading" wins: it is the one reason that goes away by waiting.
            throw gerr(codes.includes('NOT_READY') ? 'NOT_READY' : (codes[0] || 'NO_DATA'), 'no panel could answer');
          }
          return mergeResults(results, missing, slotOf, t);
        })
      };

      // A timelapse's panels move on by themselves (the time sync): ask what each table depends
      // on now, and redraw once a new state has held for a whole tick — like the page does.
      let pollTimer = null, polling = false;
      const pending = new Map();
      const poll = async () => {
        if (!this._open || polling) return;
        const table = ui.getTable();
        if (!table) return;
        polling = true;
        try {
          let fire = false;
          await Promise.all(live().filter(p => descriptions.get(p.index)?.tables.some(x => x.id === table)).map(async (p) => {
            try {
              const a = await ctx.panels.request(p.index, 'REQUEST_GRAPH_DATA', { op: 'key', table }, { timeoutMs: 4000 });
              const prev = lastKeys.get(p.index);
              if (a.key !== null && prev !== undefined && a.key !== prev) {
                if (pending.get(p.index) === a.key) fire = true; else pending.set(p.index, a.key);
              } else pending.delete(p.index);
            } catch (_) { /* a panel that does not answer is not a change */ }
          }));
          if (fire) { pending.clear(); ui.redraw(); }
        } finally { polling = false; }
      };
      const releasePanels = () => {
        lastKeys.clear();
        pending.clear();
        for (const p of live()) ctx.panels.request(p.index, 'REQUEST_GRAPH_DATA', { op: 'release' }, { timeoutMs: 5000 }).catch(() => {});
      };
      const drawer = ctx.ui.addDrawer({
        id: 'graphs', title: t('title'), icon: 'line-chart', html: panelHtml(t, false),
        onToggle: (open) => {
          this._open = open;
          clearInterval(pollTimer);
          pollTimer = null;
          if (open) { ui.refreshDescription(); pollTimer = setInterval(poll, 1000); }
          else { ui.release(); releasePanels(); }
        },
        onResize: () => ui.resize()
      });
      if (!drawer) return this;
      const ui = createUI(drawer.el, hostApi);
      const refresh = ui.refreshDescription;
      // The pickers are drawn from what the panels say they hold: ask before drawing.
      ui.refreshDescription = async () => { await fetchDescriptions(); refresh(); };
      // Panels come and go in bursts while datasets load: settle before asking again.
      let panelsTimer = null;
      const offPanels = ctx.panels.onChange(() => {
        if (!this._open) return;
        clearTimeout(panelsTimer);
        panelsTimer = setTimeout(() => ui.refreshDescription(), 400);
      });
      this._host = {
        ui,
        setOpen: (on) => (on ? drawer.open() : drawer.close()),
        relabel: () => {
          const keep = ui.getState();
          ui.release();
          drawer.setTitle(t('title'));
          drawer.el.innerHTML = panelHtml(t, false);
          if (window.lucide) lucide.createIcons({ nodes: [drawer.el] });
          if (this._open) { ui.refreshDescription().then(() => ui.setState(keep)); }
        },
        dispose: () => { clearTimeout(panelsTimer); clearInterval(pollTimer); offPanels?.(); ui.destroy(); drawer.remove(); }
      };
      return this;
    }
  };

  /** One result per panel in, one overlay out: series tagged with their dataset. */
  function mergeResults(items, missing, slotOf, t) {
    const first = items[0].res;
    // Names are shortened over every dataset of the question, answering or not: "Em3" / "Em6".
    const names = shortNames([...items.map(i => i.p.name), ...missing]);
    items.forEach((i, k) => { i.p = { ...i.p, full: i.p.name, name: names[k] }; });
    const out = {
      kind: first.kind, x: first.x, y: first.y, spec: first.spec, table: first.table, measureUnit: first.measureUnit,
      series: [], notes: [], datasets: items.length, extraNotes: []
    };
    const withLocal = (res) => res.series.length;
    items.forEach(({ p, res }) => {
      const ds = { index: p.index, name: p.name, slot: slotOf(p.index), local: 0 };
      if (res.kind === 'heat') {
        out.heats = out.heats || [];
        out.heats.push({ ...res.heat, ds });
        return;
      }
      res.series.forEach((s, i) => {
        const one = withLocal(res) === 1;
        out.series.push({ ...s, ds: { ...ds, local: i }, label: one ? p.name : `${p.name} · ${s.label}` });
      });
      (res.notes || []).forEach(n => { if (!out.notes.includes(n)) out.notes.push(n); });
    });
    if (first.kind === 'heat') out.kind = 'heat';
    if (missing.length) out.extraNotes.push(t('note_missing', { names: names.slice(items.length).join(', ') }));
    if (out.x && out.x.unit === 'µm' && out.kind !== 'bar') out.extraNotes.push(t('note_rangesDiffer'));
    out.statusText = items.length > 1 ? t('comparing', { n: items.length }) : '';
    return out;
  }

  PluginRegistry.implement('graphs', plugin);
})();
